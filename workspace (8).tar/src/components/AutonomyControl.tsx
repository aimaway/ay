import { useState } from 'react';
import { Settings, Zap, TrendingUp, DollarSign, Target, AlertCircle, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { autonomyLevels, mockActions } from '../data';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';

export default function AutonomyControl() {
  const [currentLevel, setCurrentLevel] = useState(3);
  const [showSimulation, setShowSimulation] = useState(false);

  // Simulated metrics data for different autonomy levels
  const metricsData = [
    { level: 'مستوى 1', accuracy: 72, cost: 100, responseTime: 120, falsePositives: 15 },
    { level: 'مستوى 2', accuracy: 81, cost: 78, responseTime: 85, falsePositives: 10 },
    { level: 'مستوى 3', accuracy: 89, cost: 55, responseTime: 45, falsePositives: 6 },
    { level: 'مستوى 4', accuracy: 93, cost: 38, responseTime: 22, falsePositives: 4 },
    { level: 'مستوى 5', accuracy: 91, cost: 32, responseTime: 12, falsePositives: 7 },
  ];

  const comparisonData = [
    { name: 'يدوي', time: 480, cost: 5000, errors: 12 },
    { name: 'مستوى 1', time: 360, cost: 4200, errors: 8 },
    { name: 'مستوى 2', time: 240, cost: 3500, errors: 5 },
    { name: 'مستوى 3', time: 120, cost: 2500, errors: 3 },
    { name: 'مستوى 4', time: 60, cost: 1800, errors: 2 },
    { name: 'مستوى 5', time: 30, cost: 1500, errors: 4 },
  ];

  const currentMetrics = metricsData[currentLevel - 1];
  const currentLevelInfo = autonomyLevels[currentLevel - 1];

  const simulateLevel = (level: number) => {
    setCurrentLevel(level);
    setShowSimulation(true);
    setTimeout(() => setShowSimulation(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-cyan-400" />
          التحكم بمستوى الاستقلالية
        </h3>
        <p className="text-sm text-gray-400 mt-1">
          إضافة الاستقلالية تدريجياً مع قياس الدقة والتكلفة
        </p>
      </div>

      {/* Autonomy Level Slider */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-sm font-semibold text-white">مستوى الاستقلالية الحالي</h4>
          <span className="text-2xl font-bold" style={{ color: currentLevelInfo.color }}>
            مستوى {currentLevel}
          </span>
        </div>

        {/* Level Selector */}
        <div className="flex items-center justify-between mb-6">
          {autonomyLevels.map((level) => (
            <button
              key={level.level}
              onClick={() => simulateLevel(level.level)}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${
                currentLevel === level.level 
                  ? 'bg-white/5 border-2 scale-110' 
                  : 'hover:bg-white/5 border border-transparent'
              }`}
              style={{ borderColor: currentLevel === level.level ? level.color : 'transparent' }}
            >
              <div 
                className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold"
                style={{ backgroundColor: `${level.color}20`, color: level.color }}
              >
                {level.level}
              </div>
              <span className="text-[10px] text-gray-400 text-center max-w-[80px]">{level.name}</span>
            </button>
          ))}
        </div>

        {/* Current Level Description */}
        <div className="p-4 rounded-lg border" style={{ borderColor: `${currentLevelInfo.color}40`, backgroundColor: `${currentLevelInfo.color}08` }}>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4" style={{ color: currentLevelInfo.color }} />
            <span className="text-sm font-semibold" style={{ color: currentLevelInfo.color }}>
              {currentLevelInfo.name}
            </span>
          </div>
          <p className="text-xs text-gray-300">{currentLevelInfo.description}</p>
        </div>

        {/* Simulation Result */}
        {showSimulation && (
          <div className="mt-4 p-3 rounded-lg bg-cyan-500/5 border border-cyan-500/20 animate-fade-in-up">
            <p className="text-xs text-cyan-400 flex items-center gap-2">
              <Zap className="w-3 h-3" />
              تم التبديل إلى المستوى {currentLevel} - جاري إعادة حساب المقاييس...
            </p>
          </div>
        )}
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-green-400" />
            <span className="text-[10px] text-gray-400">الدقة</span>
          </div>
          <p className="text-xl font-bold text-green-400">{currentMetrics.accuracy}%</p>
          <div className="flex items-center gap-1 mt-1">
            {currentLevel > 1 && currentMetrics.accuracy > metricsData[currentLevel - 2].accuracy ? (
              <><ArrowUp className="w-3 h-3 text-green-400" /><span className="text-[10px] text-green-400">+{currentMetrics.accuracy - metricsData[currentLevel - 2].accuracy}%</span></>
            ) : currentLevel > 1 ? (
              <><ArrowDown className="w-3 h-3 text-red-400" /><span className="text-[10px] text-red-400">{currentMetrics.accuracy - metricsData[currentLevel - 2].accuracy}%</span></>
            ) : (
              <><Minus className="w-3 h-3 text-gray-400" /><span className="text-[10px] text-gray-400">خط الأساس</span></>
            )}
          </div>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-cyan-400" />
            <span className="text-[10px] text-gray-400">التكلفة النسبية</span>
          </div>
          <p className="text-xl font-bold text-cyan-400">{currentMetrics.cost}%</p>
          <div className="flex items-center gap-1 mt-1">
            {currentLevel > 1 && currentMetrics.cost < metricsData[currentLevel - 2].cost ? (
              <><ArrowDown className="w-3 h-3 text-green-400" /><span className="text-[10px] text-green-400">أقل تكلفة</span></>
            ) : currentLevel > 1 ? (
              <><ArrowUp className="w-3 h-3 text-red-400" /><span className="text-[10px] text-red-400">أعلى تكلفة</span></>
            ) : (
              <><Minus className="w-3 h-3 text-gray-400" /><span className="text-[10px] text-gray-400">خط الأساس</span></>
            )}
          </div>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span className="text-[10px] text-gray-400">زمن الاستجابة (دقيقة)</span>
          </div>
          <p className="text-xl font-bold text-yellow-400">{currentMetrics.responseTime}</p>
          <div className="flex items-center gap-1 mt-1">
            {currentLevel > 1 && currentMetrics.responseTime < metricsData[currentLevel - 2].responseTime ? (
              <><ArrowDown className="w-3 h-3 text-green-400" /><span className="text-[10px] text-green-400">أسرع</span></>
            ) : (
              <><Minus className="w-3 h-3 text-gray-400" /><span className="text-[10px] text-gray-400">-</span></>
            )}
          </div>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-4 h-4 text-red-400" />
            <span className="text-[10px] text-gray-400">الإيجابيات الكاذبة</span>
          </div>
          <p className="text-xl font-bold text-red-400">{currentMetrics.falsePositives}%</p>
          <div className="flex items-center gap-1 mt-1">
            {currentLevel > 1 && currentMetrics.falsePositives < metricsData[currentLevel - 2].falsePositives ? (
              <><ArrowDown className="w-3 h-3 text-green-400" /><span className="text-[10px] text-green-400">أقل</span></>
            ) : currentLevel > 1 ? (
              <><ArrowUp className="w-3 h-3 text-red-400" /><span className="text-[10px] text-red-400">أعلى</span></>
            ) : (
              <><Minus className="w-3 h-3 text-gray-400" /><span className="text-[10px] text-gray-400">خط الأساس</span></>
            )}
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Accuracy vs Cost Chart */}
        <div className="glass-card p-5">
          <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-purple-400" />
            الدقة مقابل التكلفة عبر المستويات
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={metricsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="level" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0a0e1a', border: '1px solid #1e3a5f', borderRadius: '8px' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Legend />
                <Line type="monotone" dataKey="accuracy" stroke="#00ff88" name="الدقة %" strokeWidth={2} dot={{ fill: '#00ff88' }} />
                <Line type="monotone" dataKey="cost" stroke="#00d4ff" name="التكلفة النسبية" strokeWidth={2} dot={{ fill: '#00d4ff' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Comparison Bar Chart */}
        <div className="glass-card p-5">
          <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            مقارنة الأداء (الوقت بالدقائق)
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0a0e1a', border: '1px solid #1e3a5f', borderRadius: '8px' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Legend />
                <Bar dataKey="time" fill="#a855f7" name="الوقت (دقيقة)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="errors" fill="#ff4444" name="الأخطاء" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Theoretical Framework */}
      <div className="glass-card p-5 border-purple-500/20">
        <h4 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
          <Settings className="w-4 h-4 text-purple-400" />
          الإطار النظري: خوارزمية تخصيص الاستقلالية
        </h4>
        <div className="p-4 rounded-lg bg-black/30 border border-gray-800">
          <div className="terminal-text space-y-2">
            <p className="text-cyan-400"># خوارزمية تخصيص الاستقلالية (Autonomy Allocation Algorithm)</p>
            <p className="text-gray-400"># تعتمد على: مستوى الخطر × الثقة × الأمان × التكلفة</p>
            <p className="text-green-400 mt-2">function calculateAutonomyLevel(risk, confidence, safety, cost):</p>
            <p className="text-gray-300 mr-4">riskScore = risk.severity × risk.exploitability / 100</p>
            <p className="text-gray-300 mr-4">actionScore = confidence × safety / 100</p>
            <p className="text-gray-300 mr-4">costBenefit = baseline_cost / current_cost</p>
            <p className="text-gray-300 mr-4 mt-1">compositeScore = (actionScore × 0.4) + (1 - riskScore) × 0.3 + costBenefit × 0.3</p>
            <p className="text-gray-300 mr-4 mt-1">if compositeScore {'>'} 0.9: return 5  # مستقل بالكامل</p>
            <p className="text-gray-300 mr-4">elif compositeScore {'>'} 0.75: return 4  # مستقل مع إشراف</p>
            <p className="text-gray-300 mr-4">elif compositeScore {'>'} 0.6: return 3  # شبه مستقل</p>
            <p className="text-gray-300 mr-4">elif compositeScore {'>'} 0.4: return 2  # مقترح مع موافقة</p>
            <p className="text-gray-300 mr-4">else: return 1  # مراقب فقط</p>
            <p className="text-yellow-400 mt-2"># النتيجة: المستوى الأمثل = f(ثقة, أمان, تكلفة, خطورة)</p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-purple-500/5 border border-purple-500/20">
            <p className="text-xs text-purple-400 font-semibold mb-1">📐 الإطار النظري</p>
            <p className="text-[10px] text-gray-400">نموذج رياضي لتخصيص الاستقلالية بناءً على معايير متعددة</p>
          </div>
          <div className="p-3 rounded-lg bg-cyan-500/5 border border-cyan-500/20">
            <p className="text-xs text-cyan-400 font-semibold mb-1">🧪 مجموعة الاختبارات</p>
            <p className="text-[10px] text-gray-400">مجموعة اختبارات قابلة لإعادة الاستخدام لقياس الأداء عبر المستويات</p>
          </div>
          <div className="p-3 rounded-lg bg-green-500/5 border border-green-500/20">
            <p className="text-xs text-green-400 font-semibold mb-1">🚀 نظام أولي قابل للتسويق</p>
            <p className="text-[10px] text-gray-400">نموذج أولي متكامل مع واجهة احترافية وتقارير مدعومة بالأدلة</p>
          </div>
        </div>
      </div>
    </div>
  );
}
