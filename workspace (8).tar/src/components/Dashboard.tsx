import { Shield, AlertTriangle, Brain, CheckCircle, TrendingUp, Clock, DollarSign, Activity } from 'lucide-react';
import { mockAssets, mockRisks, mockActions, mockTestResults } from '../data';
import { useApp } from '../App';

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { t } = useApp();
  
  const criticalRisks = mockRisks.filter(r => r.severity === 'critical').length;
  const highRisks = mockRisks.filter(r => r.severity === 'high').length;
  const verifiedActions = mockActions.filter(a => a.status === 'verified').length;
  const totalActions = mockActions.length;
  const avgConfidence = Math.round(mockActions.reduce((a, b) => a + b.confidence, 0) / mockActions.length);
  const avgSafety = Math.round(mockActions.reduce((a, b) => a + b.safetyScore, 0) / mockActions.length);
  const testsPassed = mockTestResults.filter(t => t.passed).length;
  const totalTests = mockTestResults.length;

  const stats = [
    { label: t.discoveredAssets, value: mockAssets.length, icon: Shield, color: 'cyan', change: '+2 new' },
    { label: t.criticalRisks, value: criticalRisks, icon: AlertTriangle, color: 'rose', change: 'Requires immediate action' },
    { label: t.highRisks, value: highRisks, icon: AlertTriangle, color: 'amber', change: 'Should be addressed' },
    { label: t.actionsExecuted, value: `${verifiedActions}/${totalActions}`, icon: CheckCircle, color: 'emerald', change: `${Math.round(verifiedActions/totalActions*100)}% complete` },
    { label: t.aiConfidence, value: `${avgConfidence}%`, icon: Brain, color: 'purple', change: 'Average predictions' },
    { label: t.safetyScore, value: `${avgSafety}%`, icon: Shield, color: 'blue', change: 'Average actions' },
    { label: t.testsPassed, value: `${testsPassed}/${totalTests}`, icon: Activity, color: 'emerald', change: `${Math.round(testsPassed/totalTests*100)}% success` },
    { label: t.costSaved, value: '$2,450', icon: DollarSign, color: 'teal', change: 'vs manual approach' },
  ];

  const colorClasses = {
    cyan: 'from-cyan-500/10 to-cyan-500/5 border-cyan-500/20 hover:border-cyan-500/40',
    rose: 'from-rose-500/10 to-rose-500/5 border-rose-500/20 hover:border-rose-500/40',
    amber: 'from-amber-500/10 to-amber-500/5 border-amber-500/20 hover:border-amber-500/40',
    emerald: 'from-emerald-500/10 to-emerald-500/5 border-emerald-500/20 hover:border-emerald-500/40',
    purple: 'from-purple-500/10 to-purple-500/5 border-purple-500/20 hover:border-purple-500/40',
    blue: 'from-blue-500/10 to-blue-500/5 border-blue-500/20 hover:border-blue-500/40',
    teal: 'from-teal-500/10 to-teal-500/5 border-teal-500/20 hover:border-teal-500/40',
  };

  const iconColors = {
    cyan: 'text-cyan-400',
    rose: 'text-rose-400',
    amber: 'text-amber-400',
    emerald: 'text-emerald-400',
    purple: 'text-purple-400',
    blue: 'text-blue-400',
    teal: 'text-teal-400',
  };

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="glass-card p-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-purple-500/5" />
        <div className="relative z-10">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center shadow-xl shadow-cyan-500/20 animate-float">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">{t.aiDefenseAssistant}</h2>
              <p className="text-slate-400 text-lg">{t.aiDefenseSubtitle}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-black/30 rounded-xl p-4 border border-slate-700/50 hover:border-cyan-500/30 transition-colors">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span className="text-xs text-cyan-400 font-semibold uppercase tracking-wide">{t.lastScan}</span>
              </div>
              <p className="text-sm text-white font-medium">January 15, 2026 - 10:30 AM</p>
            </div>
            <div className="bg-black/30 rounded-xl p-4 border border-slate-700/50 hover:border-emerald-500/30 transition-colors">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-emerald-400 font-semibold uppercase tracking-wide">{t.trend}</span>
              </div>
              <p className="text-sm text-white font-medium">15% improvement in security posture</p>
            </div>
            <div className="bg-black/30 rounded-xl p-4 border border-slate-700/50 hover:border-purple-500/30 transition-colors">
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-purple-400 font-semibold uppercase tracking-wide">{t.aiMode}</span>
              </div>
              <p className="text-sm text-white font-medium">Semi-Autonomous - Level 3</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div
              key={i}
              className={`metric-card bg-gradient-to-br ${colorClasses[stat.color as keyof typeof colorClasses]} animate-fade-in-up`}
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-10 h-10 rounded-xl bg-black/30 flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${iconColors[stat.color as keyof typeof iconColors]}`} />
                </div>
                <span className="text-[10px] text-slate-500 font-medium">{stat.change}</span>
              </div>
              <p className="metric-value">{stat.value}</p>
              <p className="metric-label">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent AI Actions */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              {t.latestAIPredictions}
            </h3>
            <button 
              onClick={() => onNavigate('predictor')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold transition-colors"
            >
              {t.viewAll}
            </button>
          </div>
          <div className="space-y-3">
            {mockActions.slice(0, 4).map((action) => (
              <div key={action.id} className="flex items-center gap-3 p-3 rounded-xl bg-black/20 border border-slate-800/50 hover:border-cyan-500/30 transition-all duration-200 group cursor-pointer">
                <div className={`w-2 h-2 rounded-full ${
                  action.status === 'verified' ? 'bg-emerald-400' :
                  action.status === 'approved' ? 'bg-blue-400' :
                  action.status === 'testing' ? 'bg-amber-400' :
                  'bg-slate-400'
                }`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium truncate group-hover:text-cyan-300 transition-colors">{action.title}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Confidence: {action.confidence}% | Safety: {action.safetyScore}%</p>
                </div>
                <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${
                  action.status === 'verified' ? 'bg-emerald-500/10 text-emerald-400' :
                  action.status === 'approved' ? 'bg-blue-500/10 text-blue-400' :
                  action.status === 'testing' ? 'bg-amber-500/10 text-amber-400' :
                  'bg-slate-500/10 text-slate-400'
                }`}>
                  {action.status === 'verified' ? 'Verified' :
                   action.status === 'approved' ? 'Approved' :
                   action.status === 'testing' ? 'Testing' : 'Proposed'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Priority Queue */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
              {t.riskPriorityQueue}
            </h3>
            <button 
              onClick={() => onNavigate('risks')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold transition-colors"
            >
              {t.viewAll}
            </button>
          </div>
          <div className="space-y-3">
            {mockRisks.sort((a, b) => b.priority - a.priority).slice(0, 4).map((risk) => (
              <div key={risk.id} className="flex items-center gap-3 p-3 rounded-xl bg-black/20 border border-slate-800/50 hover:border-rose-500/30 transition-all duration-200 group cursor-pointer">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold ${
                  risk.severity === 'critical' ? 'bg-rose-500/20 text-rose-400' :
                  risk.severity === 'high' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {risk.cvssScore}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium truncate group-hover:text-rose-300 transition-colors">{risk.title}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Priority: {risk.priority} | Exploitability: {risk.exploitability}%</p>
                </div>
                <div className="w-20">
                  <div className="progress-bar">
                    <div 
                      className={`progress-fill ${
                        risk.severity === 'critical' ? 'bg-gradient-to-r from-rose-500 to-red-500' :
                        risk.severity === 'high' ? 'bg-gradient-to-r from-amber-500 to-orange-500' :
                        'bg-gradient-to-r from-yellow-500 to-amber-500'
                      }`}
                      style={{ width: `${risk.priority}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pipeline Status */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          {t.processingPipeline}
        </h3>
        <div className="flex items-center justify-between overflow-x-auto pb-2">
          {[
            { label: 'Asset Discovery', count: mockAssets.length, status: 'done', color: 'emerald' },
            { label: 'Risk Assessment', count: mockRisks.length, status: 'done', color: 'emerald' },
            { label: 'Priority Ranking', count: mockRisks.length, status: 'done', color: 'emerald' },
            { label: 'Action Prediction', count: mockActions.length, status: 'done', color: 'emerald' },
            { label: 'Safe Testing', count: `${testsPassed}/${totalTests}`, status: 'active', color: 'amber' },
            { label: 'Report Generation', count: 'In Progress', status: 'pending', color: 'slate' },
          ].map((step, i) => (
            <div key={i} className="flex items-center gap-3 flex-shrink-0">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center border-2 ${
                step.status === 'done' ? 'border-emerald-500 bg-emerald-500/10' :
                step.status === 'active' ? 'border-amber-500 bg-amber-500/10 animate-pulse' :
                'border-slate-700 bg-slate-800/50'
              }`}>
                <span className={`text-sm font-bold ${
                  step.status === 'done' ? 'text-emerald-400' :
                  step.status === 'active' ? 'text-amber-400' :
                  'text-slate-500'
                }`}>
                  {step.status === 'done' ? '✓' : i + 1}
                </span>
              </div>
              <div>
                <p className="text-xs text-white font-semibold">{step.label}</p>
                <p className="text-[10px] text-slate-500">{step.count}</p>
              </div>
              {i < 5 && (
                <div className={`w-12 h-0.5 mx-2 ${
                  step.status === 'done' ? 'bg-gradient-to-r from-emerald-500 to-emerald-500/50' : 'bg-slate-700'
                }`} />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
