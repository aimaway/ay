import { useState } from 'react';
import { Shield, CheckCircle, XCircle, Clock, Play, RotateCcw, FlaskConical } from 'lucide-react';
import { mockActions, mockTestResults } from '../data';

export default function SafeTesting() {
  const [runningTests, setRunningTests] = useState(false);
  const [testProgress, setTestProgress] = useState(0);

  const runTests = () => {
    setRunningTests(true);
    setTestProgress(0);
    const interval = setInterval(() => {
      setTestProgress(prev => {
        if (prev >= 100) { clearInterval(interval); setRunningTests(false); return 100; }
        return prev + 5;
      });
    }, 200);
  };

  const getActionTitle = (actionId: string) => mockActions.find(a => a.id === actionId)?.title || '';
  const passedCount = mockTestResults.filter(t => t.passed).length;
  const failedCount = mockTestResults.filter(t => !t.passed).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h3 className="text-2xl font-bold text-white flex items-center gap-2">
            <FlaskConical className="w-6 h-6 text-cyan-400" />
            Safe Testing Environment
          </h3>
          <p className="text-slate-400 mt-1">Test proposed actions in an isolated sandbox before production execution</p>
        </div>
        <button onClick={runTests} disabled={runningTests} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold transition-all ${runningTests ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' : 'btn-primary'}`}>
          {runningTests ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          {runningTests ? 'Running Tests...' : 'Run Tests'}
        </button>
      </div>

      <div className="glass-card p-5 border-cyan-500/20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center"><p className="text-xl font-bold text-cyan-400">Sandbox</p><p className="text-[10px] text-slate-400">Test Environment</p></div>
          <div className="text-center"><p className="text-xl font-bold text-emerald-400">Isolated</p><p className="text-[10px] text-slate-400">Network Status</p></div>
          <div className="text-center"><p className="text-xl font-bold text-purple-400">{mockTestResults.length}</p><p className="text-[10px] text-slate-400">Total Tests</p></div>
          <div className="text-center"><p className="text-xl font-bold text-emerald-400">{Math.round(passedCount / mockTestResults.length * 100)}%</p><p className="text-[10px] text-slate-400">Success Rate</p></div>
        </div>
      </div>

      {runningTests && (
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-cyan-400 font-semibold">Test Progress</span>
            <span className="text-xs text-white font-bold">{testProgress}%</span>
          </div>
          <div className="progress-bar"><div className="progress-fill" style={{ width: `${testProgress}%` }} /></div>
          <div className="terminal mt-4 space-y-1">
            {testProgress >= 10 && <p className="terminal-info">[ENV] Initializing isolated test environment...</p>}
            {testProgress >= 25 && <p className="terminal-success">[TEST] Testing patch action on web server...</p>}
            {testProgress >= 40 && <p className="terminal-success">[TEST] Verifying service availability after patch...</p>}
            {testProgress >= 55 && <p className="terminal-success">[TEST] Testing database credential change...</p>}
            {testProgress >= 70 && <p className="terminal-warning">[TEST] Testing S3 access restriction...</p>}
            {testProgress >= 85 && <p className="terminal-warning">[TEST] Testing SMBv1 disable...</p>}
            {testProgress >= 95 && <p className="terminal-info">[DONE] Collecting test results...</p>}
          </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-4">
        <div className="glass-card p-5 text-center border-emerald-500/20">
          <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
          <p className="text-3xl font-bold text-emerald-400">{passedCount}</p>
          <p className="text-xs text-slate-400 font-medium">Tests Passed</p>
        </div>
        <div className="glass-card p-5 text-center border-rose-500/20">
          <XCircle className="w-10 h-10 text-rose-400 mx-auto mb-2" />
          <p className="text-3xl font-bold text-rose-400">{failedCount}</p>
          <p className="text-xs text-slate-400 font-medium">Tests Failed</p>
        </div>
        <div className="glass-card p-5 text-center border-cyan-500/20">
          <Clock className="w-10 h-10 text-cyan-400 mx-auto mb-2" />
          <p className="text-3xl font-bold text-cyan-400">14s</p>
          <p className="text-xs text-slate-400 font-medium">Total Time</p>
        </div>
      </div>

      <div className="space-y-3">
        <h4 className="text-lg font-bold text-white">Test Results Details</h4>
        {mockTestResults.map((test, index) => (
          <div key={test.id} className={`glass-card p-4 border-l-4 ${test.passed ? 'border-emerald-500' : 'border-rose-500'} animate-fade-in-up`} style={{ animationDelay: `${index * 0.1}s` }}>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                {test.passed ? <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5" /> : <XCircle className="w-5 h-5 text-rose-400 mt-0.5" />}
                <div>
                  <p className="text-sm font-semibold text-white">{test.testName}</p>
                  <p className="text-xs text-slate-400 mt-0.5">Action: <span className="text-cyan-400">{getActionTitle(test.actionId)}</span></p>
                  <p className="text-xs text-slate-300 mt-2">{test.details}</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${test.passed ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                  {test.passed ? 'Passed' : 'Failed'}
                </span>
                <p className="text-[10px] text-slate-500 mt-1">{test.duration}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="glass-card p-5 border-emerald-500/20">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-5 h-5 text-emerald-400" />
          <h4 className="text-lg font-bold text-white">Sandbox Safety Confirmation</h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {['Environment completely isolated from production', 'No external network access', 'Backup available for rollback', 'Full test log monitoring'].map((item, i) => (
            <div key={i} className="flex items-center gap-2 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-slate-300">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
