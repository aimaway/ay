// English data for CyberShield AI

export interface Asset {
  id: string;
  name: string;
  type: 'server' | 'database' | 'endpoint' | 'network' | 'application' | 'cloud';
  ip: string;
  os?: string;
  criticality: 'critical' | 'high' | 'medium' | 'low';
  status: 'active' | 'inactive' | 'vulnerable';
  lastScan: string;
  openPorts?: number[];
  services?: string[];
}

export interface Risk {
  id: string;
  assetId: string;
  title: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  cvssScore: number;
  description: string;
  exploitability: number;
  businessImpact: number;
  priority: number;
  cve?: string;
  discoveredAt: string;
}

export interface AIAction {
  id: string;
  riskId: string;
  actionType: 'patch' | 'isolate' | 'block' | 'monitor' | 'remediate' | 'scan';
  title: string;
  description: string;
  reasoning: string;
  confidence: number;
  safetyScore: number;
  estimatedTime: string;
  cost: number;
  successProbability: number;
  evidence: string[];
  status: 'proposed' | 'testing' | 'approved' | 'executed' | 'verified';
  autonomyLevel: number;
}

export interface TestResult {
  id: string;
  actionId: string;
  testName: string;
  passed: boolean;
  duration: string;
  details: string;
  timestamp: string;
}

export const mockAssets: Asset[] = [
  {
    id: 'asset-1',
    name: 'Web Server Primary',
    type: 'server',
    ip: '10.0.1.10',
    os: 'Ubuntu 22.04',
    criticality: 'critical',
    status: 'vulnerable',
    lastScan: '2026-01-15T10:30:00Z',
    openPorts: [22, 80, 443, 8080],
    services: ['nginx', 'node.js', 'ssh']
  },
  {
    id: 'asset-2',
    name: 'Database Server',
    type: 'database',
    ip: '10.0.1.20',
    os: 'CentOS 8',
    criticality: 'critical',
    status: 'vulnerable',
    lastScan: '2026-01-15T10:30:00Z',
    openPorts: [3306, 22],
    services: ['mysql', 'ssh']
  },
  {
    id: 'asset-3',
    name: 'API Gateway',
    type: 'application',
    ip: '10.0.1.30',
    os: 'Alpine Linux',
    criticality: 'high',
    status: 'active',
    lastScan: '2026-01-15T10:30:00Z',
    openPorts: [443, 8443],
    services: ['kong', 'nginx']
  },
  {
    id: 'asset-4',
    name: 'Employee Workstations',
    type: 'endpoint',
    ip: '10.0.2.0/24',
    os: 'Windows 11',
    criticality: 'medium',
    status: 'active',
    lastScan: '2026-01-15T10:30:00Z',
    openPorts: [135, 139, 445],
    services: ['smb', 'rdp']
  },
  {
    id: 'asset-5',
    name: 'Cloud Storage (S3)',
    type: 'cloud',
    ip: 'AWS S3 Bucket',
    criticality: 'high',
    status: 'vulnerable',
    lastScan: '2026-01-15T10:30:00Z',
    services: ['s3', 'iam']
  },
  {
    id: 'asset-6',
    name: 'Firewall / WAF',
    type: 'network',
    ip: '10.0.0.1',
    criticality: 'critical',
    status: 'active',
    lastScan: '2026-01-15T10:30:00Z',
    openPorts: [443],
    services: ['waf', 'ids']
  }
];

export const mockRisks: Risk[] = [
  {
    id: 'risk-1',
    assetId: 'asset-1',
    title: 'Outdated Nginx with Known RCE',
    severity: 'critical',
    cvssScore: 9.8,
    description: 'Nginx version 1.18.0 has a known remote code execution vulnerability (CVE-2024-7262)',
    exploitability: 92,
    businessImpact: 95,
    priority: 97,
    cve: 'CVE-2024-7262',
    discoveredAt: '2026-01-15T10:35:00Z'
  },
  {
    id: 'risk-2',
    assetId: 'asset-2',
    title: 'MySQL Default Credentials',
    severity: 'critical',
    cvssScore: 9.1,
    description: 'MySQL is accessible with default root credentials, allowing full database compromise',
    exploitability: 88,
    businessImpact: 98,
    priority: 95,
    discoveredAt: '2026-01-15T10:36:00Z'
  },
  {
    id: 'risk-3',
    assetId: 'asset-5',
    title: 'S3 Bucket Public Access',
    severity: 'high',
    cvssScore: 7.5,
    description: 'S3 bucket containing sensitive data is publicly accessible without authentication',
    exploitability: 95,
    businessImpact: 85,
    priority: 90,
    discoveredAt: '2026-01-15T10:37:00Z'
  },
  {
    id: 'risk-4',
    assetId: 'asset-4',
    title: 'SMBv1 Enabled on Workstations',
    severity: 'high',
    cvssScore: 8.1,
    description: 'SMBv1 protocol is enabled, vulnerable to EternalBlue exploit',
    exploitability: 75,
    businessImpact: 70,
    priority: 78,
    cve: 'CVE-2017-0144',
    discoveredAt: '2026-01-15T10:38:00Z'
  },
  {
    id: 'risk-5',
    assetId: 'asset-1',
    title: 'Missing Security Headers',
    severity: 'medium',
    cvssScore: 5.3,
    description: 'Web server missing CSP, HSTS, and X-Frame-Options headers',
    exploitability: 45,
    businessImpact: 40,
    priority: 55,
    discoveredAt: '2026-01-15T10:39:00Z'
  },
  {
    id: 'risk-6',
    assetId: 'asset-3',
    title: 'API Rate Limiting Not Configured',
    severity: 'medium',
    cvssScore: 5.8,
    description: 'API gateway has no rate limiting, vulnerable to DDoS and brute force',
    exploitability: 60,
    businessImpact: 55,
    priority: 62,
    discoveredAt: '2026-01-15T10:40:00Z'
  }
];

export const mockActions: AIAction[] = [
  {
    id: 'action-1',
    riskId: 'risk-1',
    actionType: 'patch',
    title: 'Patch Nginx to v1.25.4',
    description: 'Update Nginx from 1.18.0 to 1.25.4 to fix CVE-2024-7262',
    reasoning: 'This is the highest priority risk due to CVSS 9.8 and active exploit availability. Patching is the most effective remediation with minimal service disruption.',
    confidence: 96,
    safetyScore: 94,
    estimatedTime: '15 min',
    cost: 0,
    successProbability: 97,
    evidence: [
      'CVE-2024-7262 confirmed in NVD database',
      'Patch tested in staging environment',
      'No breaking changes between 1.18 and 1.25',
      'Backup created before patching'
    ],
    status: 'verified',
    autonomyLevel: 3
  },
  {
    id: 'action-2',
    riskId: 'risk-2',
    actionType: 'remediate',
    title: 'Change MySQL Root Password & Restrict Access',
    description: 'Set strong password for MySQL root user and restrict access to application server only',
    reasoning: 'Default credentials on a critical database pose immediate compromise risk. Changing credentials and restricting network access provides defense-in-depth.',
    confidence: 93,
    safetyScore: 91,
    estimatedTime: '10 min',
    cost: 0,
    successProbability: 95,
    evidence: [
      'Default credentials verified via safe scan',
      'New password meets complexity requirements',
      'Firewall rules tested in sandbox',
      'Application connectivity verified post-change'
    ],
    status: 'verified',
    autonomyLevel: 3
  },
  {
    id: 'action-3',
    riskId: 'risk-3',
    actionType: 'block',
    title: 'Disable Public S3 Access & Apply Bucket Policy',
    description: 'Remove public access block and apply restrictive bucket policy with IAM-only access',
    reasoning: 'Public S3 exposure is the most common cloud data breach vector. Immediate remediation prevents data exfiltration.',
    confidence: 91,
    safetyScore: 89,
    estimatedTime: '5 min',
    cost: 0,
    successProbability: 99,
    evidence: [
      'Bucket contents audited - contains PII data',
      'IAM roles configured for application access',
      'No active public consumers identified',
      'Change is reversible via AWS Console'
    ],
    status: 'approved',
    autonomyLevel: 2
  },
  {
    id: 'action-4',
    riskId: 'risk-4',
    actionType: 'remediate',
    title: 'Disable SMBv1 via Group Policy',
    description: 'Deploy GPO to disable SMBv1 across all workstations in the domain',
    reasoning: 'SMBv1 is deprecated and exploited by WannaCry/NotPetya. Disabling via GPO ensures consistent enforcement.',
    confidence: 88,
    safetyScore: 85,
    estimatedTime: '30 min',
    cost: 50,
    successProbability: 92,
    evidence: [
      'GPO tested on pilot group (5 machines)',
      'No legacy applications require SMBv1',
      'Rollback plan documented',
      'Change window: maintenance period'
    ],
    status: 'testing',
    autonomyLevel: 2
  },
  {
    id: 'action-5',
    riskId: 'risk-5',
    actionType: 'remediate',
    title: 'Add Security Headers to Nginx Config',
    description: 'Add CSP, HSTS, X-Frame-Options, X-Content-Type-Options headers',
    reasoning: 'Security headers provide essential browser-side protection. Low risk change with high security benefit.',
    confidence: 95,
    safetyScore: 97,
    estimatedTime: '5 min',
    cost: 0,
    successProbability: 98,
    evidence: [
      'Headers tested in staging',
      'No CSP violations detected in report-only mode',
      'HSTS preload list compatible',
      'X-Frame-Options verified with embedded content'
    ],
    status: 'proposed',
    autonomyLevel: 4
  },
  {
    id: 'action-6',
    riskId: 'risk-6',
    actionType: 'remediate',
    title: 'Configure API Rate Limiting',
    description: 'Set rate limits: 100 req/min per IP, 1000 req/min global, with progressive penalties',
    reasoning: 'Rate limiting prevents abuse while maintaining service availability. Progressive penalties allow legitimate traffic spikes.',
    confidence: 87,
    safetyScore: 88,
    estimatedTime: '20 min',
    cost: 0,
    successProbability: 90,
    evidence: [
      'Traffic patterns analyzed - baseline established',
      'Rate limits set above 95th percentile',
      'Whitelist configured for internal services',
      'Monitoring alerts configured for threshold breaches'
    ],
    status: 'proposed',
    autonomyLevel: 3
  }
];

export const mockTestResults: TestResult[] = [
  {
    id: 'test-1',
    actionId: 'action-1',
    testName: 'Nginx Version Verification',
    passed: true,
    duration: '2.3s',
    details: 'Nginx updated to 1.25.4 - CVE-2024-7262 no longer applicable',
    timestamp: '2026-01-15T11:15:00Z'
  },
  {
    id: 'test-2',
    actionId: 'action-1',
    testName: 'Service Availability Check',
    passed: true,
    duration: '1.1s',
    details: 'HTTP 200 OK on all endpoints - no service disruption',
    timestamp: '2026-01-15T11:16:00Z'
  },
  {
    id: 'test-3',
    actionId: 'action-1',
    testName: 'Configuration Integrity',
    passed: true,
    duration: '0.8s',
    details: 'All existing configurations preserved and functional',
    timestamp: '2026-01-15T11:17:00Z'
  },
  {
    id: 'test-4',
    actionId: 'action-2',
    testName: 'Authentication Verification',
    passed: true,
    duration: '3.2s',
    details: 'New credentials working - old default credentials rejected',
    timestamp: '2026-01-15T11:20:00Z'
  },
  {
    id: 'test-5',
    actionId: 'action-2',
    testName: 'Network Access Restriction',
    passed: true,
    duration: '1.5s',
    details: 'MySQL only accessible from 10.0.1.10 - other IPs blocked',
    timestamp: '2026-01-15T11:22:00Z'
  },
  {
    id: 'test-6',
    actionId: 'action-4',
    testName: 'SMBv1 Protocol Check',
    passed: false,
    duration: '5.1s',
    details: 'SMBv1 still active on 3 workstations - GPO not yet applied',
    timestamp: '2026-01-15T11:30:00Z'
  }
];

export const autonomyLevels = [
  { level: 1, name: 'Observer Only', description: 'System monitors and suggests only - takes no action', color: '#10b981' },
  { level: 2, name: 'Proposer with Approval', description: 'Suggests actions and requires human approval before execution', color: '#00f0ff' },
  { level: 3, name: 'Semi-Autonomous', description: 'Executes low-risk actions automatically - high-risk requires approval', color: '#f59e0b' },
  { level: 4, name: 'Autonomous with Oversight', description: 'Executes most actions automatically with human notification', color: '#f97316' },
  { level: 5, name: 'Fully Autonomous', description: 'Makes all decisions and executions independently', color: '#f43f5e' },
];
