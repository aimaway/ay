# 🛡️ CyberShield AI - مساعد الدفاع السيبراني الذكي

نظام دفاع سيبراني ذكي متكامل يتنبأ بأفضل إجراء أمني تالٍ، يثبت أنه آمن وناجح، ويتدرج في الاستقلالية مع قياس الدقة والتكلفة.

## 🎯 المميزات الرئيسية

### ✅ ما تم إنجازه:

1. **واجهة أمامية كاملة** (React + TypeScript + Tailwind)
   - لوحة تحكم شاملة
   - اكتشاف الأصول ضمن نطاق مصرح
   - تقييم المخاطر وترتيب الأولويات
   - تنبؤ الذكاء الاصطناعي بالإجراءات
   - بيئة اختبار آمنة (Sandbox)
   - تقارير مدعومة بالأدلة
   - التحكم بمستوى الاستقلالية (5 مستويات)
   - **سجلات حية** (Real-time logs)

2. **Backend حقيقي** (Express + WebSocket + SQLite)
   - قاعدة بيانات SQLite مع 9 جداول
   - REST API كامل
   - WebSocket للبيانات الحية
   - محرك تحليل السجلات (Syslog/JSON/Raw)
   - محرك ذكاء اصطناعي للتنبؤات
   - نظام كشف الثغرات التلقائي

3. **أدوات استقبال البيانات الحقيقية**
   - `syslogPipe.ts` - ربط سجلات النظام مباشرة
   - `fileWatcher.ts` - مراقبة الملفات تلقائياً
   - REST API لاستقبال السجلات
   - WebSocket للبيانات الحية

## 🚀 التشغيل السريع

### 1️⃣ تثبيت الحزم (تم بالفعل)

```bash
npm install
```

### 2️⃣ تشغيل الـ Backend

```bash
# الطريقة الموصى بها (مع tsx)
npx tsx server/index.ts

# أو باستخدام TypeScript compiler
npx tsc -p tsconfig.server.json
node dist-server/index.js
```

الخادم سيعمل على: `http://localhost:3001`

### 3️⃣ تشغيل الواجهة الأمامية

```bash
npm run dev
```

الواجهة ستعمل على: `http://localhost:5173` (أو المنفذ المحدد)

### 4️⃣ فتح التطبيق

افتح المتصفح على: `http://localhost:5173`

## 📡 إرسال بيانات حقيقية

### الطريقة 1: HTTP API

```bash
# إرسال سجل واحد
curl -X POST http://localhost:3001/api/logs \
  -H "Content-Type: application/json" \
  -d '{
    "rawLog": "Jan 15 10:30:00 server sshd[1234]: Failed password for root from 192.168.1.100",
    "source": "auth.log"
  }'

# إرسال سجلات متعددة
curl -X POST http://localhost:3001/api/logs \
  -H "Content-Type: application/json" \
  -d '{
    "logs": [
      "Jan 15 10:30:00 server sshd[1234]: Failed password for root from 192.168.1.100",
      "{\"severity\":\"critical\",\"message\":\"CVE-2024-7262 exploit detected\"}",
      "ERROR malware detected on endpoint-003"
    ],
    "source": "siem-export"
  }'
```

### الطريقة 2: ربط سجلات النظام مباشرة

```bash
# Linux syslog
tail -f /var/log/syslog | npx tsx server/ingestion/syslogPipe.ts

# Auth logs
tail -f /var/log/auth.log | npx tsx server/ingestion/syslogPipe.ts --source=auth

# Nginx logs
tail -f /var/log/nginx/access.log | npx tsx server/ingestion/syslogPipe.ts --source=nginx
```

### الطريقة 3: مراقبة الملفات تلقائياً

```bash
# مراقبة مجلد كامل
npx tsx server/ingestion/fileWatcher.ts --path=/var/log --pattern="*.log"

# مراقبة مجلد التطبيق
npx tsx server/ingestion/fileWatcher.ts --path=./logs --pattern="*.json"
```

### الطريقة 4: WebSocket (Real-time)

```javascript
const ws = new WebSocket('ws://localhost:3001/ws');

// إرسال سجل
ws.send(JSON.stringify({
  type: 'log',
  payload: 'Jan 15 10:30:00 server sshd[1234]: Failed password'
}));

// استقبال الأحداث
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Event:', data.type, data.payload);
};
```

## 🗄️ قاعدة البيانات

ملف قاعدة البيانات: `data/cybershield.db`

### الجداول:

| الجدول | الوصف |
|--------|-------|
| `assets` | الأصول المكتشفة |
| `risks` | المخاطر والثغرات |
| `ai_actions` | إجراءات الذكاء الاصطناعي |
| `test_results` | نتائج الاختبارات |
| `log_entries` | السجلات المستقبلة |
| `scan_results` | نتائج الفحص |
| `autonomy_metrics` | مقاييس الاستقلالية |
| `system_config` | إعدادات النظام |
| `log_sources` | مصادر السجلات |

## 🤖 محرك الذكاء الاصطناعي

### خط الأنابيب:

```
سجل وارد → تحليل وتصنيف → ربط بالأصل → إنشاء خطر
                                              ↓
خطر مفتوح → البحث عن قالب إجراء → حساب الثقة
                                        ↓
                              حساب درجة الأمان
                                        ↓
                              حساب مستوى الاستقلالية
                                        ↓
                              توليد الأدلة
                                        ↓
                              تشغيل اختبارات Sandbox
                                        ↓
                              إنتاج تقرير
```

### قوالب الإجراءات:

- **RCE/Exploits** → ترقيع (Patch)
- **SQL Injection** → WAF + استعلامات آمنة
- **Unauthorized Access** → قفل الحساب + حظر IP
- **Malware** → عزل + علاج
- **Misconfigurations** → تقوية CIS
- **Port Scans** → مراقبة + إغلاق منافذ

## 📊 مستويات الاستقلالية

| المستوى | الوصف | الاستخدام |
|---------|-------|----------|
| 1 | مراقب فقط | البداية - النظام يقترح فقط |
| 2 | مقترح مع موافقة | يتطلب موافقة بشرية |
| 3 | شبه مستقل | منخفض المخاطر تلقائياً |
| 4 | مستقل مع إشراف | معظم الإجراءات تلقائياً |
| 5 | مستقل بالكامل | جميع القرارات مستقلة |

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | فحص الصحة |
| GET | `/api/dashboard/stats` | إحصائيات لوحة التحكم |
| GET | `/api/assets` | قائمة الأصول |
| POST | `/api/assets` | تسجيل أصل جديد |
| PUT | `/api/assets/:id` | تحديث أصل |
| GET | `/api/risks` | قائمة المخاطر |
| PUT | `/api/risks/:id/status` | تحديث حالة خطر |
| GET | `/api/actions` | قائمة الإجراءات |
| PUT | `/api/actions/:id/status` | تحديث حالة إجراء |
| POST | `/api/ai/process-risks` | تشغيل معالجة الذكاء الاصطناعي |
| POST | `/api/ai/generate-action/:riskId` | توليد إجراء لخطر |
| POST | `/api/testing/run/:actionId` | تشغيل اختبارات الأمان |
| GET | `/api/testing/results/:actionId` | نتائج الاختبارات |
| GET | `/api/logs` | السجلات الحديثة |
| POST | `/api/logs` | **استقبال سجلات (نقطة الدخول الرئيسية)** |
| GET | `/api/config` | إعدادات النظام |
| PUT | `/api/config/autonomy` | تعيين مستوى الاستقلالية |
| PUT | `/api/config/scope` | تعيين النطاق المصرح |

## 🧪 اختبار النظام

### اختبار 1: إرسال سجل هجوم محاكى

```bash
curl -X POST http://localhost:3001/api/logs \
  -H "Content-Type: application/json" \
  -d '{"rawLog": "CRITICAL: SQL injection attempt from 10.0.2.100 targeting /api/users?id=1 OR 1=1", "source": "waf"}'
```

### اختبار 2: التحقق من إنشاء خطر

```bash
curl http://localhost:3001/api/risks | jq '.data[0]'
```

### اختبار 3: تشغيل الذكاء الاصطناعي

```bash
curl -X POST http://localhost:3001/api/ai/process-risks | jq '.data'
```

### اختبار 4: تشغيل اختبارات الأمان

```bash
# الحصول على معرف الإجراء أولاً
ACTION_ID=$(curl -s http://localhost:3001/api/actions | jq -r '.data[0].id')
curl -X POST http://localhost:3001/api/testing/run/$ACTION_ID | jq '.data'
```

## 📈 ما يجعل هذا حقيقياً (ليس محاكاة)

1. **قاعدة بيانات حقيقية**: SQLite يخزن جميع البيانات بشكل دائم
2. **تحليل سجلات حقيقي**: تحليل syslog/JSON فعلي مع مطابقة الأنماط
3. **كشف مخاطر حقيقي**: تحديد الثغرات بناءً على الأنماط
4. **خط أنابيب ذكاء اصطناعي حقيقي**: توليد إجراءات مع تسجيل النقاط
5. **WebSocket حقيقي**: اتصال ثنائي الاتجاه مباشر
6. **REST API حقيقي**: عمليات CRUD كاملة
7. **اختبارات حقيقية**: إطار عمل اختبار Sandbox
8. **مقاييس حقيقية**: حساب مستوى الاستقلالية بناءً على بيانات فعلية

## 🔄 النشر الإنتاجي

### متغيرات البيئة

```bash
PORT=3001
HOST=0.0.0.0
NODE_ENV=production
VITE_API_URL=http://your-domain:3001/api
VITE_WS_URL=ws://your-domain:3001/ws
```

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
RUN npx tsc -p tsconfig.server.json
EXPOSE 3001
CMD ["node", "dist-server/index.js"]
```

### Systemd Service

```ini
[Unit]
Description=CyberShield AI Backend
After=network.target

[Service]
Type=simple
User=cybershield
WorkingDirectory=/opt/cybershield
ExecStart=/usr/bin/npx tsx server/index.ts
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

## 📚 الوثائق الكاملة

راجع `BACKEND_GUIDE.md` للحصول على وثائق مفصلة عن:
- بنية النظام
- جميع API endpoints
- تنسيقات السجلات المدعومة
- التكامل مع SIEM
- النشر الإنتاجي

## 🎓 المخرجات العلمية

هذا المشروع ينتج:

1. **إطار نظري**: نموذج رياضي لتخصيص الاستقلالية
2. **خوارزمية**: `calculateAutonomyLevel(risk, confidence, safety)`
3. **مجموعة اختبارات**: قابلة لإعادة الاستخدام لقياس الأداء
4. **نظام أولي قابل للتسويق**: واجهة احترافية + backend حقيقي

## 🛠️ التقنيات المستخدمة

### Frontend
- React 18 + TypeScript
- Vite
- Tailwind CSS
- Recharts (للرسوم البيانية)
- Lucide React (للأيقونات)

### Backend
- Node.js + TypeScript
- Express.js
- WebSocket (ws)
- SQLite (better-sqlite3)
- UUID
- Helmet (للأمان)
- CORS

## 📝 ملاحظات مهمة

- النظام جاهز لاستقبال البيانات الحقيقية
- ابدأ بالمستوى 1 (مراقب فقط) ثم تدرج
- اختبر في بيئة معزولة قبل الإنتاج
- راقب المقاييس قبل رفع الاستقلالية
- احتفظ بنسخ احتياطية من قاعدة البيانات

## 🤝 المساهمة

هذا مشروع بحثي/تعليمي. للمساهمة:
1. اختبر مع بيانات حقيقية
2. أضف قوالب إجراءات جديدة
3. حسّن خوارزميات التنبؤ
4. أضف مصادر سجلات جديدة
5. شارك النتائج والمقاييس

## 📄 الترخيص

مشروع تعليمي/بحثي - للاستخدام الأكاديمي والتجاري

---

**تم التطوير بواسطة**: CyberShield AI Team  
**الإصدار**: 1.0.0  
**التاريخ**: يناير 2026
