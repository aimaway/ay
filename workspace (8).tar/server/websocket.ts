import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { processLogBatch, parseLogLine, processLog } from './ingestion/logParser';
import { processAllRisks } from './ai/predictor';
import { getDashboardStats, getRecentLogs, getAllAssets, getAllRisks, getAllActions } from './database';
import type { WebSocketMessage } from './types';

let wss: WebSocketServer;
const clients: Set<WebSocket> = new Set();

/**
 * Initialize WebSocket server for real-time data streaming
 */
export function initWebSocketServer(server: Server): WebSocketServer {
  wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws: WebSocket, req) => {
    const clientIp = req.socket.remoteAddress;
    console.log(`[WS] New client connected from ${clientIp}`);
    clients.add(ws);

    // Send initial state
    ws.send(JSON.stringify({
      type: 'system_status',
      payload: {
        status: 'connected',
        message: 'Connected to CyberShield AI real-time feed',
        timestamp: new Date().toISOString(),
      },
      timestamp: new Date().toISOString(),
    } as WebSocketMessage));

    // Handle incoming messages from clients
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        handleClientMessage(ws, message);
      } catch (err) {
        // Try to process as raw log
        const rawLog = data.toString().trim();
        if (rawLog) {
          handleIncomingLog(rawLog, clientIp || 'unknown');
        }
      }
    });

    ws.on('close', () => {
      console.log(`[WS] Client disconnected: ${clientIp}`);
      clients.delete(ws);
    });

    ws.on('error', (err) => {
      console.error(`[WS] Client error from ${clientIp}:`, err.message);
      clients.delete(ws);
    });
  });

  console.log('[WS] WebSocket server initialized on /ws');
  return wss;
}

/**
 * Handle messages from connected clients
 */
function handleClientMessage(ws: WebSocket, message: any): void {
  switch (message.type) {
    case 'subscribe':
      // Client wants to subscribe to specific event types
      console.log(`[WS] Client subscribed to: ${message.topics}`);
      break;
      
    case 'log':
      // Client sending a log entry
      if (message.payload) {
        handleIncomingLog(
          typeof message.payload === 'string' ? message.payload : JSON.stringify(message.payload),
          'websocket-client'
        );
      }
      break;

    case 'batch_logs':
      // Client sending multiple logs
      if (Array.isArray(message.payload)) {
        const results = processLogBatch(message.payload, 'websocket-batch');
        broadcast({
          type: 'log',
          payload: {
            processed: results.entries.length,
            risksFound: results.risks.length,
          },
          timestamp: new Date().toISOString(),
        });
      }
      break;

    case 'trigger_scan':
      // Trigger AI processing
      const actions = processAllRisks();
      broadcast({
        type: 'action_update',
        payload: {
          message: `AI generated ${actions.length} new actions`,
          actions: actions.map(a => ({ id: a.id, title: a.titleAr, confidence: a.confidence })),
        },
        timestamp: new Date().toISOString(),
      });
      break;

    case 'ping':
      ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
      break;

    default:
      console.log(`[WS] Unknown message type: ${message.type}`);
  }
}

/**
 * Handle incoming raw log data
 */
function handleIncomingLog(rawLog: string, source: string): void {
  try {
    const parsed = parseLogLine(rawLog, source);
    const result = processLog(parsed);

    // Broadcast log entry
    broadcast({
      type: 'log',
      payload: {
        id: result.logEntry.id,
        severity: result.logEntry.severity,
        source: result.logEntry.source,
        message: result.logEntry.message,
        timestamp: result.logEntry.timestamp,
      },
      timestamp: new Date().toISOString(),
    });

    // If a risk was created, broadcast it and trigger AI
    if (result.risk) {
      broadcast({
        type: 'risk_alert',
        payload: {
          id: result.risk.id,
          severity: result.risk.severity,
          title: result.risk.titleAr,
          cvssScore: result.risk.cvssScore,
          assetId: result.risk.assetId,
          timestamp: result.risk.discoveredAt,
        },
        timestamp: new Date().toISOString(),
      });

      // Automatically generate AI action for the new risk
      const { generateActionForRisk } = require('./ai/predictor');
      const action = generateActionForRisk(result.risk);
      if (action) {
        broadcast({
          type: 'action_update',
          payload: {
            id: action.id,
            title: action.titleAr,
            confidence: action.confidence,
            safetyScore: action.safetyScore,
            autonomyLevel: action.autonomyLevel,
            status: action.status,
          },
          timestamp: new Date().toISOString(),
        });
      }
    }
  } catch (err) {
    console.error('[WS] Error processing log:', err);
  }
}

/**
 * Broadcast a message to all connected clients
 */
export function broadcast(message: WebSocketMessage): void {
  const data = JSON.stringify(message);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  }
}

/**
 * Broadcast system status update
 */
export function broadcastStatusUpdate(): void {
  const stats = getDashboardStats();
  broadcast({
    type: 'system_status',
    payload: stats,
    timestamp: new Date().toISOString(),
  });
}

/**
 * Get count of connected clients
 */
export function getClientCount(): number {
  return clients.size;
}

/**
 * Close WebSocket server
 */
export function closeWebSocketServer(): void {
  if (wss) {
    for (const client of clients) {
      client.close();
    }
    wss.close();
  }
}
