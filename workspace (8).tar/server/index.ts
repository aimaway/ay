import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import http from 'http';
import { initDatabase } from './database';
import { initWebSocketServer, broadcastStatusUpdate } from './websocket';
import apiRouter from './routes/api';

const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || '0.0.0.0';

// Initialize database
console.log('[SERVER] Initializing database...');
initDatabase();

// Create Express app
const app = express();

// Middleware
app.use(helmet({
  contentSecurityPolicy: false, // Allow WebSocket connections
}));
app.use(cors({
  origin: '*', // In production, restrict to your frontend domain
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.text({ type: 'text/*' }));

// Request logging middleware
app.use((req, _res, next) => {
  console.log(`[API] ${req.method} ${req.path} - ${new Date().toISOString()}`);
  next();
});

// API Routes
app.use('/api', apiRouter);

// Root endpoint
app.get('/', (_req, res) => {
  res.json({
    name: 'CyberShield AI Backend',
    version: '1.0.0',
    description: 'AI-powered Cybersecurity Defense Assistant - Real Backend',
    endpoints: {
      dashboard: '/api/dashboard/stats',
      assets: '/api/assets',
      risks: '/api/risks',
      actions: '/api/actions',
      logs: '/api/logs',
      ai: '/api/ai/process-risks',
      testing: '/api/testing/run/:actionId',
      config: '/api/config',
      websocket: 'ws://localhost:' + PORT + '/ws',
      health: '/api/health',
    },
    documentation: {
      logIngestion: {
        endpoint: 'POST /api/logs',
        formats: [
          'JSON: { "logs": ["log1", "log2"], "source": "my-siem" }',
          'Single: { "rawLog": "raw log line", "source": "syslog" }',
          'WebSocket: Send logs via ws://localhost:' + PORT + '/ws',
        ],
        supportedFormats: ['JSON logs', 'Syslog', 'Raw text', 'CSV'],
      },
      assetRegistration: {
        endpoint: 'POST /api/assets',
        body: {
          name: 'string',
          type: 'server|database|endpoint|network|application|cloud',
          ip: 'string (IP address)',
          os: 'string (optional)',
          criticality: 'critical|high|medium|low',
          status: 'active|inactive|vulnerable|unknown',
          openPorts: 'number[] (optional)',
          services: 'string[] (optional)',
        },
      },
      aiProcessing: {
        endpoint: 'POST /api/ai/process-risks',
        description: 'Triggers AI to analyze all open risks and generate optimal actions',
      },
      safeTesting: {
        endpoint: 'POST /api/testing/run/:actionId',
        description: 'Runs safety tests for an action in the sandbox environment',
      },
    },
  });
});

// Create HTTP server
const server = http.createServer(app);

// Initialize WebSocket server
initWebSocketServer(server);

// Periodic status broadcast (every 30 seconds)
setInterval(() => {
  broadcastStatusUpdate();
}, 30000);

// Start server
server.listen(Number(PORT), HOST as string, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════════════╗');
  console.log('║          CyberShield AI - Backend Server v1.0.0             ║');
  console.log('║     AI-Powered Cybersecurity Defense Assistant               ║');
  console.log('╠══════════════════════════════════════════════════════════════╣');
  console.log(`║  HTTP Server:    http://${HOST}:${PORT}                        ║`);
  console.log(`║  WebSocket:      ws://${HOST}:${PORT}/ws                       ║`);
  console.log(`║  API Base:       http://${HOST}:${PORT}/api                    ║`);
  console.log('╠══════════════════════════════════════════════════════════════╣');
  console.log('║  Ready to receive real logs and data!                        ║');
  console.log('║                                                              ║');
  console.log('║  Send logs via:                                              ║');
  console.log('║  • POST /api/logs (JSON batch)                               ║');
  console.log('║  • POST /api/logs/syslog (Syslog format)                     ║');
  console.log('║  • WebSocket ws://localhost:3001/ws                          ║');
  console.log('║  • Pipe from: tail -f /var/log/syslog | nc localhost 3001    ║');
  console.log('╚══════════════════════════════════════════════════════════════╝');
  console.log('');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[SERVER] SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('[SERVER] Server closed.');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('[SERVER] SIGINT received. Shutting down...');
  server.close(() => {
    console.log('[SERVER] Server closed.');
    process.exit(0);
  });
});

export default app;
