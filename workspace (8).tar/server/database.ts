import Database from 'better-sqlite3';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import type {
  Asset, Risk, AIAction, TestResult, LogEntry,
  ScanResult, ScanFinding, SystemConfig, AutonomyMetrics
} from './types';

const DB_PATH = path.join(process.cwd(), 'data', 'cybershield.db');

// Ensure data directory exists
import fs from 'fs';
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

let db: Database.Database;

export function initDatabase(): Database.Database {
  db = new Database(DB_PATH);
  
  // Enable WAL mode for better concurrent performance
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // Create tables
  db.exec(`
    -- Assets table
    CREATE TABLE IF NOT EXISTS assets (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('server', 'database', 'endpoint', 'network', 'application', 'cloud')),
      ip TEXT NOT NULL,
      os TEXT,
      criticality TEXT NOT NULL CHECK(criticality IN ('critical', 'high', 'medium', 'low')),
      status TEXT NOT NULL DEFAULT 'unknown' CHECK(status IN ('active', 'inactive', 'vulnerable', 'unknown')),
      last_scan TEXT,
      open_ports TEXT, -- JSON array
      services TEXT, -- JSON array
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Risks table
    CREATE TABLE IF NOT EXISTS risks (
      id TEXT PRIMARY KEY,
      asset_id TEXT NOT NULL REFERENCES assets(id),
      title TEXT NOT NULL,
      title_ar TEXT,
      severity TEXT NOT NULL CHECK(severity IN ('critical', 'high', 'medium', 'low')),
      cvss_score REAL NOT NULL DEFAULT 0,
      description TEXT,
      description_ar TEXT,
      exploitability REAL NOT NULL DEFAULT 0,
      business_impact REAL NOT NULL DEFAULT 0,
      priority REAL NOT NULL DEFAULT 0,
      cve TEXT,
      discovered_at TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_at TEXT,
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open', 'mitigating', 'resolved', 'accepted'))
    );

    -- AI Actions table
    CREATE TABLE IF NOT EXISTS ai_actions (
      id TEXT PRIMARY KEY,
      risk_id TEXT NOT NULL REFERENCES risks(id),
      action_type TEXT NOT NULL CHECK(action_type IN ('patch', 'isolate', 'block', 'monitor', 'remediate', 'scan')),
      title TEXT NOT NULL,
      title_ar TEXT,
      description TEXT,
      description_ar TEXT,
      reasoning TEXT,
      reasoning_ar TEXT,
      confidence REAL NOT NULL DEFAULT 0,
      safety_score REAL NOT NULL DEFAULT 0,
      estimated_time TEXT,
      cost REAL NOT NULL DEFAULT 0,
      success_probability REAL NOT NULL DEFAULT 0,
      evidence TEXT, -- JSON array
      evidence_ar TEXT, -- JSON array
      status TEXT NOT NULL DEFAULT 'proposed' CHECK(status IN ('proposed', 'testing', 'approved', 'executed', 'verified', 'failed')),
      autonomy_level INTEGER NOT NULL DEFAULT 1 CHECK(autonomy_level BETWEEN 1 AND 5),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      executed_at TEXT
    );

    -- Test results table
    CREATE TABLE IF NOT EXISTS test_results (
      id TEXT PRIMARY KEY,
      action_id TEXT NOT NULL REFERENCES ai_actions(id),
      test_name TEXT NOT NULL,
      test_name_ar TEXT,
      passed INTEGER NOT NULL DEFAULT 0,
      duration TEXT,
      details TEXT,
      details_ar TEXT,
      timestamp TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Log entries table
    CREATE TABLE IF NOT EXISTS log_entries (
      id TEXT PRIMARY KEY,
      timestamp TEXT NOT NULL,
      source TEXT NOT NULL,
      source_ip TEXT,
      destination_ip TEXT,
      severity TEXT NOT NULL CHECK(severity IN ('info', 'warning', 'error', 'critical')),
      message TEXT NOT NULL,
      raw_log TEXT NOT NULL,
      parsed INTEGER NOT NULL DEFAULT 0,
      asset_id TEXT REFERENCES assets(id),
      risk_id TEXT REFERENCES risks(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Scan results table
    CREATE TABLE IF NOT EXISTS scan_results (
      id TEXT PRIMARY KEY,
      asset_id TEXT NOT NULL REFERENCES assets(id),
      scan_type TEXT NOT NULL CHECK(scan_type IN ('port', 'vulnerability', 'compliance', 'configuration')),
      findings TEXT, -- JSON array of ScanFinding
      started_at TEXT NOT NULL,
      completed_at TEXT,
      status TEXT NOT NULL DEFAULT 'running' CHECK(status IN ('running', 'completed', 'failed'))
    );

    -- Autonomy metrics table
    CREATE TABLE IF NOT EXISTS autonomy_metrics (
      id TEXT PRIMARY KEY,
      level INTEGER NOT NULL CHECK(level BETWEEN 1 AND 5),
      accuracy REAL NOT NULL,
      cost_reduction REAL NOT NULL,
      response_time REAL NOT NULL,
      false_positives REAL NOT NULL,
      decisions_made INTEGER NOT NULL DEFAULT 0,
      human_overrides INTEGER NOT NULL DEFAULT 0,
      timestamp TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- System config table
    CREATE TABLE IF NOT EXISTS system_config (
      id TEXT PRIMARY KEY DEFAULT 'main',
      authorized_scope TEXT NOT NULL DEFAULT '10.0.0.0/16',
      autonomy_level INTEGER NOT NULL DEFAULT 1 CHECK(autonomy_level BETWEEN 1 AND 5),
      scan_schedule TEXT NOT NULL DEFAULT '0 */6 * * *',
      alert_thresholds TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Log sources table
    CREATE TABLE IF NOT EXISTS log_sources (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('syslog', 'api', 'file', 'websocket')),
      endpoint TEXT,
      port INTEGER,
      format TEXT NOT NULL DEFAULT 'json' CHECK(format IN ('json', 'syslog', 'csv', 'raw')),
      enabled INTEGER NOT NULL DEFAULT 1
    );

    -- Create indexes for performance
    CREATE INDEX IF NOT EXISTS idx_risks_asset_id ON risks(asset_id);
    CREATE INDEX IF NOT EXISTS idx_risks_severity ON risks(severity);
    CREATE INDEX IF NOT EXISTS idx_risks_priority ON risks(priority DESC);
    CREATE INDEX IF NOT EXISTS idx_ai_actions_risk_id ON ai_actions(risk_id);
    CREATE INDEX IF NOT EXISTS idx_ai_actions_status ON ai_actions(status);
    CREATE INDEX IF NOT EXISTS idx_log_entries_timestamp ON log_entries(timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_log_entries_severity ON log_entries(severity);
    CREATE INDEX IF NOT EXISTS idx_log_entries_source ON log_entries(source);
    CREATE INDEX IF NOT EXISTS idx_scan_results_asset_id ON scan_results(asset_id);
  `);

  // Insert default config if not exists
  const configExists = db.prepare('SELECT id FROM system_config WHERE id = ?').get('main');
  if (!configExists) {
    db.prepare(`
      INSERT INTO system_config (id, authorized_scope, autonomy_level, scan_schedule, alert_thresholds)
      VALUES ('main', '10.0.0.0/16', 1, '0 */6 * * *', ?)
    `).run(JSON.stringify({
      criticalRiskCount: 1,
      highRiskCount: 5,
      responseTimeSeconds: 300,
      falsePositiveRate: 0.1
    }));
  }

  console.log('[DB] Database initialized at:', DB_PATH);
  return db;
}

export function getDb(): Database.Database {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

// ============ ASSET OPERATIONS ============

export function createAsset(asset: Omit<Asset, 'id' | 'createdAt' | 'updatedAt'>): Asset {
  const id = uuidv4();
  const now = new Date().toISOString();
  
  getDb().prepare(`
    INSERT INTO assets (id, name, type, ip, os, criticality, status, last_scan, open_ports, services, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, asset.name, asset.type, asset.ip, asset.os || null,
    asset.criticality, asset.status, asset.lastScan || now,
    JSON.stringify(asset.openPorts || []),
    JSON.stringify(asset.services || []),
    now, now
  );

  return { ...asset, id, createdAt: now, updatedAt: now };
}

export function getAllAssets(): Asset[] {
  const rows = getDb().prepare('SELECT * FROM assets ORDER BY updated_at DESC').all() as any[];
  return rows.map(rowToAsset);
}

export function getAssetById(id: string): Asset | null {
  const row = getDb().prepare('SELECT * FROM assets WHERE id = ?').get(id) as any;
  return row ? rowToAsset(row) : null;
}

export function getAssetByIp(ip: string): Asset | null {
  const row = getDb().prepare('SELECT * FROM assets WHERE ip = ?').get(ip) as any;
  return row ? rowToAsset(row) : null;
}

export function updateAsset(id: string, updates: Partial<Asset>): Asset | null {
  const existing = getAssetById(id);
  if (!existing) return null;

  const now = new Date().toISOString();
  const fields: string[] = [];
  const values: any[] = [];

  if (updates.name !== undefined) { fields.push('name = ?'); values.push(updates.name); }
  if (updates.type !== undefined) { fields.push('type = ?'); values.push(updates.type); }
  if (updates.ip !== undefined) { fields.push('ip = ?'); values.push(updates.ip); }
  if (updates.os !== undefined) { fields.push('os = ?'); values.push(updates.os); }
  if (updates.criticality !== undefined) { fields.push('criticality = ?'); values.push(updates.criticality); }
  if (updates.status !== undefined) { fields.push('status = ?'); values.push(updates.status); }
  if (updates.lastScan !== undefined) { fields.push('last_scan = ?'); values.push(updates.lastScan); }
  if (updates.openPorts !== undefined) { fields.push('open_ports = ?'); values.push(JSON.stringify(updates.openPorts)); }
  if (updates.services !== undefined) { fields.push('services = ?'); values.push(JSON.stringify(updates.services)); }
  
  fields.push('updated_at = ?');
  values.push(now);
  values.push(id);

  getDb().prepare(`UPDATE assets SET ${fields.join(', ')} WHERE id = ?`).run(...values);
  return getAssetById(id);
}

function rowToAsset(row: any): Asset {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    ip: row.ip,
    os: row.os || undefined,
    criticality: row.criticality,
    status: row.status,
    lastScan: row.last_scan,
    openPorts: row.open_ports ? JSON.parse(row.open_ports) : undefined,
    services: row.services ? JSON.parse(row.services) : undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// ============ RISK OPERATIONS ============

export function createRisk(risk: Omit<Risk, 'id' | 'discoveredAt'>): Risk {
  const id = uuidv4();
  const now = new Date().toISOString();
  
  // Calculate priority
  const priority = Math.round(
    (risk.exploitability * 0.4 + risk.businessImpact * 0.4 + risk.cvssScore * 10 * 0.2)
  );

  getDb().prepare(`
    INSERT INTO risks (id, asset_id, title, title_ar, severity, cvss_score, description, description_ar, exploitability, business_impact, priority, cve, discovered_at, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, risk.assetId, risk.title, risk.titleAr, risk.severity,
    risk.cvssScore, risk.description, risk.descriptionAr,
    risk.exploitability, risk.businessImpact, priority,
    risk.cve || null, now, risk.status || 'open'
  );

  return { ...risk, id, priority, discoveredAt: now };
}

export function getAllRisks(): Risk[] {
  const rows = getDb().prepare('SELECT * FROM risks ORDER BY priority DESC').all() as any[];
  return rows.map(rowToRisk);
}

export function getRisksByAsset(assetId: string): Risk[] {
  const rows = getDb().prepare('SELECT * FROM risks WHERE asset_id = ? ORDER BY priority DESC').all(assetId) as any[];
  return rows.map(rowToRisk);
}

export function getRisksBySeverity(severity: string): Risk[] {
  const rows = getDb().prepare('SELECT * FROM risks WHERE severity = ? ORDER BY priority DESC').all(severity) as any[];
  return rows.map(rowToRisk);
}

export function updateRiskStatus(id: string, status: Risk['status']): void {
  const resolvedAt = status === 'resolved' ? new Date().toISOString() : null;
  getDb().prepare('UPDATE risks SET status = ?, resolved_at = ? WHERE id = ?').run(status, resolvedAt, id);
}

function rowToRisk(row: any): Risk {
  return {
    id: row.id,
    assetId: row.asset_id,
    title: row.title,
    titleAr: row.title_ar,
    severity: row.severity,
    cvssScore: row.cvss_score,
    description: row.description,
    descriptionAr: row.description_ar,
    exploitability: row.exploitability,
    businessImpact: row.business_impact,
    priority: row.priority,
    cve: row.cve || undefined,
    discoveredAt: row.discovered_at,
    resolvedAt: row.resolved_at || undefined,
    status: row.status,
  };
}

// ============ AI ACTION OPERATIONS ============

export function createAIAction(action: Omit<AIAction, 'id' | 'createdAt'>): AIAction {
  const id = uuidv4();
  const now = new Date().toISOString();

  getDb().prepare(`
    INSERT INTO ai_actions (id, risk_id, action_type, title, title_ar, description, description_ar, reasoning, reasoning_ar, confidence, safety_score, estimated_time, cost, success_probability, evidence, evidence_ar, status, autonomy_level, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, action.riskId, action.actionType, action.title, action.titleAr,
    action.description, action.descriptionAr, action.reasoning, action.reasoningAr,
    action.confidence, action.safetyScore, action.estimatedTime, action.cost,
    action.successProbability, JSON.stringify(action.evidence), JSON.stringify(action.evidenceAr),
    action.status, action.autonomyLevel, now
  );

  return { ...action, id, createdAt: now };
}

export function getAllActions(): AIAction[] {
  const rows = getDb().prepare('SELECT * FROM ai_actions ORDER BY created_at DESC').all() as any[];
  return rows.map(rowToAction);
}

export function getActionsByRisk(riskId: string): AIAction[] {
  const rows = getDb().prepare('SELECT * FROM ai_actions WHERE risk_id = ? ORDER BY confidence DESC').all(riskId) as any[];
  return rows.map(rowToAction);
}

export function updateActionStatus(id: string, status: AIAction['status']): void {
  const executedAt = status === 'executed' || status === 'verified' ? new Date().toISOString() : null;
  if (executedAt) {
    getDb().prepare('UPDATE ai_actions SET status = ?, executed_at = ? WHERE id = ?').run(status, executedAt, id);
  } else {
    getDb().prepare('UPDATE ai_actions SET status = ? WHERE id = ?').run(status, id);
  }
}

function rowToAction(row: any): AIAction {
  return {
    id: row.id,
    riskId: row.risk_id,
    actionType: row.action_type,
    title: row.title,
    titleAr: row.title_ar,
    description: row.description,
    descriptionAr: row.description_ar,
    reasoning: row.reasoning,
    reasoningAr: row.reasoning_ar,
    confidence: row.confidence,
    safetyScore: row.safety_score,
    estimatedTime: row.estimated_time,
    cost: row.cost,
    successProbability: row.success_probability,
    evidence: row.evidence ? JSON.parse(row.evidence) : [],
    evidenceAr: row.evidence_ar ? JSON.parse(row.evidence_ar) : [],
    status: row.status,
    autonomyLevel: row.autonomy_level,
    createdAt: row.created_at,
    executedAt: row.executed_at || undefined,
  };
}

// ============ LOG OPERATIONS ============

export function createLogEntry(log: Omit<LogEntry, 'id' | 'createdAt'>): LogEntry {
  const id = uuidv4();
  const now = new Date().toISOString();

  getDb().prepare(`
    INSERT INTO log_entries (id, timestamp, source, source_ip, destination_ip, severity, message, raw_log, parsed, asset_id, risk_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, log.timestamp, log.source, log.sourceIp || null, log.destinationIp || null,
    log.severity, log.message, log.rawLog, log.parsed ? 1 : 0,
    log.assetId || null, log.riskId || null, now
  );

  return { ...log, id, createdAt: now };
}

export function getRecentLogs(limit: number = 100): LogEntry[] {
  const rows = getDb().prepare('SELECT * FROM log_entries ORDER BY timestamp DESC LIMIT ?').all(limit) as any[];
  return rows.map(rowToLog);
}

export function getLogsBySeverity(severity: string, limit: number = 100): LogEntry[] {
  const rows = getDb().prepare('SELECT * FROM log_entries WHERE severity = ? ORDER BY timestamp DESC LIMIT ?').all(severity, limit) as any[];
  return rows.map(rowToLog);
}

export function getLogsByAsset(assetId: string, limit: number = 100): LogEntry[] {
  const rows = getDb().prepare('SELECT * FROM log_entries WHERE asset_id = ? ORDER BY timestamp DESC LIMIT ?').all(assetId, limit) as any[];
  return rows.map(rowToLog);
}

export function getLogCount(): number {
  const result = getDb().prepare('SELECT COUNT(*) as count FROM log_entries').get() as any;
  return result.count;
}

function rowToLog(row: any): LogEntry {
  return {
    id: row.id,
    timestamp: row.timestamp,
    source: row.source,
    sourceIp: row.source_ip || undefined,
    destinationIp: row.destination_ip || undefined,
    severity: row.severity,
    message: row.message,
    rawLog: row.raw_log,
    parsed: row.parsed === 1,
    assetId: row.asset_id || undefined,
    riskId: row.risk_id || undefined,
    createdAt: row.created_at,
  };
}

// ============ TEST RESULT OPERATIONS ============

export function createTestResult(result: Omit<TestResult, 'id' | 'timestamp'>): TestResult {
  const id = uuidv4();
  const now = new Date().toISOString();

  getDb().prepare(`
    INSERT INTO test_results (id, action_id, test_name, test_name_ar, passed, duration, details, details_ar, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, result.actionId, result.testName, result.testNameAr,
    result.passed ? 1 : 0, result.duration, result.details, result.detailsAr, now
  );

  return { ...result, id, timestamp: now };
}

export function getTestResultsByAction(actionId: string): TestResult[] {
  const rows = getDb().prepare('SELECT * FROM test_results WHERE action_id = ? ORDER BY timestamp DESC').all(actionId) as any[];
  return rows.map((row: any) => ({
    id: row.id,
    actionId: row.action_id,
    testName: row.test_name,
    testNameAr: row.test_name_ar,
    passed: row.passed === 1,
    duration: row.duration,
    details: row.details,
    detailsAr: row.details_ar,
    timestamp: row.timestamp,
  }));
}

// ============ SYSTEM CONFIG ============

export function getSystemConfig(): SystemConfig | null {
  const row = getDb().prepare('SELECT * FROM system_config WHERE id = ?').get('main') as any;
  if (!row) return null;
  
  return {
    id: row.id,
    authorizedScope: row.authorized_scope,
    autonomyLevel: row.autonomy_level,
    logSources: [],
    scanSchedule: row.scan_schedule,
    alertThresholds: JSON.parse(row.alert_thresholds),
  };
}

export function updateAutonomyLevel(level: number): void {
  getDb().prepare('UPDATE system_config SET autonomy_level = ?, updated_at = datetime(\'now\') WHERE id = ?').run(level, 'main');
}

export function updateAuthorizedScope(scope: string): void {
  getDb().prepare('UPDATE system_config SET authorized_scope = ?, updated_at = datetime(\'now\') WHERE id = ?').run(scope, 'main');
}

// ============ DASHBOARD STATS ============

export function getDashboardStats(): any {
  const totalAssets = (getDb().prepare('SELECT COUNT(*) as c FROM assets').get() as any).c;
  const vulnerableAssets = (getDb().prepare("SELECT COUNT(*) as c FROM assets WHERE status = 'vulnerable'").get() as any).c;
  const totalRisks = (getDb().prepare("SELECT COUNT(*) as c FROM risks WHERE status = 'open'").get() as any).c;
  const criticalRisks = (getDb().prepare("SELECT COUNT(*) as c FROM risks WHERE severity = 'critical' AND status = 'open'").get() as any).c;
  const highRisks = (getDb().prepare("SELECT COUNT(*) as c FROM risks WHERE severity = 'high' AND status = 'open'").get() as any).c;
  const actionsProposed = (getDb().prepare('SELECT COUNT(*) as c FROM ai_actions').get() as any).c;
  const actionsVerified = (getDb().prepare("SELECT COUNT(*) as c FROM ai_actions WHERE status = 'verified'").get() as any).c;
  const logsProcessed = getLogCount();
  
  const avgConfRow = getDb().prepare('SELECT AVG(confidence) as avg FROM ai_actions').get() as any;
  const avgSafetyRow = getDb().prepare('SELECT AVG(safety_score) as avg FROM ai_actions').get() as any;
  const lastScanRow = getDb().prepare('SELECT MAX(last_scan) as last FROM assets').get() as any;

  return {
    totalAssets,
    vulnerableAssets,
    totalRisks,
    criticalRisks,
    highRisks,
    actionsProposed,
    actionsVerified,
    avgConfidence: Math.round(avgConfRow.avg || 0),
    avgSafety: Math.round(avgSafetyRow.avg || 0),
    testsPassed: 0,
    totalTests: 0,
    logsProcessed,
    lastScanTime: lastScanRow.last || new Date().toISOString(),
  };
}
