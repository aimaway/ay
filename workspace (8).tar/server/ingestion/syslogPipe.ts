#!/usr/bin/env node
/**
 * Syslog Pipe - Forward system logs to CyberShield AI backend
 * 
 * Usage:
 *   tail -f /var/log/syslog | npx tsx server/ingestion/syslogPipe.ts
 *   tail -f /var/log/auth.log | npx tsx server/ingestion/syslogPipe.ts
 *   cat /var/log/nginx/access.log | npx tsx server/ingestion/syslogPipe.ts
 * 
 * Or with any log source:
 *   your-log-command | npx tsx server/ingestion/syslogPipe.ts --source "my-app"
 */

import http from 'http';
import readline from 'readline';

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3001';
const SOURCE = process.argv.find(arg => arg.startsWith('--source='))?.split('=')[1] || 'stdin';
const BATCH_SIZE = parseInt(process.env.BATCH_SIZE || '10');
const BATCH_TIMEOUT = parseInt(process.env.BATCH_TIMEOUT || '5000');

let buffer: string[] = [];
let batchTimer: NodeJS.Timeout | null = null;

console.log(`
╔══════════════════════════════════════════════════════╗
║  CyberShield AI - Syslog Pipe                        ║
║  Forwarding logs to: ${BACKEND_URL.padEnd(28)}║
║  Source: ${SOURCE.padEnd(40)}║
║  Batch size: ${String(BATCH_SIZE).padEnd(36)}║
╚══════════════════════════════════════════════════════╝
`);

function sendBatch(): void {
  if (buffer.length === 0) return;

  const logsToSend = [...buffer];
  buffer = [];

  const payload = JSON.stringify({
    logs: logsToSend,
    source: SOURCE,
  });

  const url = new URL('/api/logs', BACKEND_URL);
  
  const req = http.request({
    hostname: url.hostname,
    port: url.port,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload),
    },
  }, (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      try {
        const result = JSON.parse(data);
        if (result.success) {
          console.log(`[PIPE] ✓ Sent ${logsToSend.length} logs → ${result.data?.entriesProcessed || 0} processed, ${result.data?.risksCreated || 0} risks found`);
        } else {
          console.error(`[PIPE] ✗ API error: ${result.error}`);
        }
      } catch {
        console.log(`[PIPE] Sent ${logsToSend.length} logs (status: ${res.statusCode})`);
      }
    });
  });

  req.on('error', (err) => {
    console.error(`[PIPE] ✗ Connection error: ${err.message}`);
    console.error(`[PIPE] Make sure the backend is running: npx tsx server/index.ts`);
    // Re-add to buffer for retry
    buffer = [...logsToSend, ...buffer];
  });

  req.write(payload);
  req.end();
}

function scheduleBatch(): void {
  if (batchTimer) clearTimeout(batchTimer);
  
  if (buffer.length >= BATCH_SIZE) {
    sendBatch();
  } else {
    batchTimer = setTimeout(sendBatch, BATCH_TIMEOUT);
  }
}

// Read from stdin
const rl = readline.createInterface({
  input: process.stdin,
  terminal: false,
});

let lineCount = 0;

rl.on('line', (line: string) => {
  if (!line.trim()) return;
  
  buffer.push(line);
  lineCount++;
  
  if (lineCount % 100 === 0) {
    console.log(`[PIPE] 📊 Processed ${lineCount} lines so far...`);
  }
  
  scheduleBatch();
});

rl.on('close', () => {
  console.log(`[PIPE] Input stream closed. Total lines: ${lineCount}`);
  // Send remaining buffer
  if (buffer.length > 0) {
    sendBatch();
  }
  setTimeout(() => process.exit(0), 1000);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[PIPE] Shutting down...');
  if (buffer.length > 0) {
    sendBatch();
  }
  setTimeout(() => process.exit(0), 500);
});

process.on('SIGTERM', () => {
  if (buffer.length > 0) {
    sendBatch();
  }
  setTimeout(() => process.exit(0), 500);
});
