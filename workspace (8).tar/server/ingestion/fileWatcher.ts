#!/usr/bin/env node
/**
 * File Watcher - Monitor log files and forward to CyberShield AI
 * 
 * Usage:
 *   npx tsx server/ingestion/fileWatcher.ts --path /var/log --pattern "*.log"
 *   npx tsx server/ingestion/fileWatcher.ts --path ./logs --pattern "*.json"
 */

import fs from 'fs';
import path from 'path';
import http from 'http';

const WATCH_PATH = process.argv.find(arg => arg.startsWith('--path='))?.split('=')[1] || './logs';
const PATTERN = process.argv.find(arg => arg.startsWith('--pattern='))?.split('=')[1] || '*.log';
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3001';

console.log(`
╔══════════════════════════════════════════════════════╗
║  CyberShield AI - File Watcher                       ║
║  Watching: ${WATCH_PATH.padEnd(38)}║
║  Pattern: ${PATTERN.padEnd(39)}║
║  Backend: ${BACKEND_URL.padEnd(38)}║
╚══════════════════════════════════════════════════════╝
`);

// Simple glob matching
function matchPattern(filename: string, pattern: string): boolean {
  const regex = new RegExp('^' + pattern.replace(/\*/g, '.*').replace(/\?/g, '.') + '$');
  return regex.test(filename);
}

function sendLog(line: string, source: string): void {
  const payload = JSON.stringify({
    rawLog: line,
    source,
  });

  const url = new URL('/api/logs', BACKEND_URL);
  
  const req = http.request({
    hostname: url.hostname,
    port: url.port,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload),
    },
  }, (res) => {
    // Silent success
  });

  req.on('error', (err) => {
    console.error(`[WATCHER] Error sending log: ${err.message}`);
  });

  req.write(payload);
  req.end();
}

function watchFile(filePath: string): void {
  const source = path.basename(filePath);
  let lastSize = 0;

  // Get initial file size
  try {
    const stats = fs.statSync(filePath);
    lastSize = stats.size;
    console.log(`[WATCHER] 📄 Watching: ${filePath} (${lastSize} bytes)`);
  } catch {
    console.error(`[WATCHER] Cannot access: ${filePath}`);
    return;
  }

  // Watch for changes
  fs.watchFile(filePath, { interval: 1000 }, (curr, prev) => {
    if (curr.size > lastSize) {
      // Read new content
      const stream = fs.createReadStream(filePath, {
        start: lastSize,
        end: curr.size,
      });

      let buffer = '';
      stream.on('data', (chunk) => {
        buffer += chunk.toString();
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Keep incomplete line in buffer

        for (const line of lines) {
          if (line.trim()) {
            sendLog(line, source);
          }
        }
      });

      lastSize = curr.size;
    } else if (curr.size < lastSize) {
      // File was truncated/rotated
      console.log(`[WATCHER] 🔄 File rotated: ${filePath}`);
      lastSize = 0;
    }
  });
}

function scanDirectory(dirPath: string): void {
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      
      if (entry.isDirectory()) {
        // Recursively scan subdirectories
        scanDirectory(fullPath);
      } else if (entry.isFile() && matchPattern(entry.name, PATTERN)) {
        watchFile(fullPath);
      }
    }
  } catch (err) {
    console.error(`[WATCHER] Error scanning ${dirPath}:`, err);
  }
}

// Also watch for new files
fs.watch(WATCH_PATH, { recursive: true }, (eventType, filename) => {
  if (filename && matchPattern(path.basename(filename), PATTERN)) {
    const fullPath = path.join(WATCH_PATH, filename);
    if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
      console.log(`[WATCHER] 📁 New file detected: ${fullPath}`);
      watchFile(fullPath);
    }
  }
});

// Initial scan
scanDirectory(WATCH_PATH);

console.log(`[WATCHER] ✓ Watching for changes... (Ctrl+C to stop)`);

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[WATCHER] Stopping file watcher...');
  process.exit(0);
});
