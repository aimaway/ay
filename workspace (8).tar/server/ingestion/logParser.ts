import { v4 as uuidv4 } from 'uuid';
import { createLogEntry, getAssetByIp, createRisk } from '../database';
import type { LogEntry, Risk } from '../types';

// Known vulnerability signatures for pattern matching
const VULNERABILITY_PATTERNS = [
  {
    pattern: /CVE-\d{4}-\d+/i,
    extractCve: (match: string) => match,
    severity: 'high' as const,
  },
  {
    pattern: /unauthorized access|authentication fail|login fail|brute force/i,
    severity: 'high' as const,
    title: 'محاولة وصول غير مصرح',
    titleEn: 'Unauthorized Access Attempt',
  },
  {
    pattern: /sql injection|union select|drop table|or 1=1/i,
    severity: 'critical' as const,
    title: 'محاولة حقن SQL',
    titleEn: 'SQL Injection Attempt',
  },
  {
    pattern: /xss|cross.site.script|<script/i,
    severity: 'high' as const,
    title: 'محاولة XSS',
    titleEn: 'Cross-Site Scripting Attempt',
  },
  {
    pattern: /port scan|nmap|syn scan|connection refused.*multiple/i,
    severity: 'medium' as const,
    title: 'مسح منافذ مكتشف',
    titleEn: 'Port Scan Detected',
  },
  {
    pattern: /malware|trojan|ransomware|virus|worm/i,
    severity: 'critical' as const,
    title: 'برمجية خبيثة مكتشفة',
    titleEn: 'Malware Detected',
  },
  {
    pattern: /privilege escalation|sudo.*fail|root access/i,
    severity: 'critical' as const,
    title: 'محاولة تصعيد صلاحيات',
    titleEn: 'Privilege Escalation Attempt',
  },
  {
    pattern: /data exfiltration|large transfer|unusual outbound/i,
    severity: 'critical' as const,
    title: 'نقل بيانات مشبوه',
    titleEn: 'Suspicious Data Transfer',
  },
  {
    pattern: /outdated.*version|EOL|end.of.life|unsupported/i,
    severity: 'medium' as const,
    title: 'إصدار قديم أو منتهي الدعم',
    titleEn: 'Outdated/End-of-Life Software',
  },
  {
    pattern: /misconfigur|default password|weak cipher|ssl.*error/i,
    severity: 'medium' as const,
    title: 'خطأ في التكوين',
    titleEn: 'Misconfiguration Detected',
  },
];

// CVSS score mapping based on severity
const SEVERITY_CVSS_MAP: Record<string, [number, number]> = {
  critical: [9.0, 10.0],
  high: [7.0, 8.9],
  medium: [4.0, 6.9],
  low: [0.1, 3.9],
};

export interface ParsedLog {
  timestamp: string;
  source: string;
  sourceIp?: string;
  destinationIp?: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  rawLog: string;
  matchedPattern?: typeof VULNERABILITY_PATTERNS[0];
  cve?: string;
}

/**
 * Parse a raw log line into structured format
 */
export function parseLogLine(rawLog: string, source: string = 'unknown'): ParsedLog {
  let timestamp = new Date().toISOString();
  let sourceIp: string | undefined;
  let destinationIp: string | undefined;
  let severity: 'info' | 'warning' | 'error' | 'critical' = 'info';
  let message = rawLog;

  // Try JSON format
  try {
    const jsonLog = JSON.parse(rawLog);
    timestamp = jsonLog.timestamp || jsonLog['@timestamp'] || jsonLog.time || timestamp;
    sourceIp = jsonLog.source_ip || jsonLog.src_ip || jsonLog.sourceIP || jsonLog.src;
    destinationIp = jsonLog.destination_ip || jsonLog.dest_ip || jsonLog.destinationIP || jsonLog.dst;
    severity = mapSeverity(jsonLog.severity || jsonLog.level || jsonLog.priority || 'info');
    message = jsonLog.message || jsonLog.msg || jsonLog.description || rawLog;
  } catch {
    // Try syslog format: "Jan  1 12:00:00 hostname program[pid]: message"
    const syslogMatch = rawLog.match(/^(\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+(\S+?)(?:\[(\d+)\])?:\s+(.+)$/);
    if (syslogMatch) {
      const [, ts, host, program, , msg] = syslogMatch;
      timestamp = parseSyslogTimestamp(ts);
      source = `${host}/${program}`;
      message = msg;
      
      // Extract IPs from message
      const ipMatches = msg.match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/g);
      if (ipMatches && ipMatches.length >= 1) sourceIp = ipMatches[0];
      if (ipMatches && ipMatches.length >= 2) destinationIp = ipMatches[1];
    }

    // Try to detect severity from message
    if (/critical|emergency|fatal|panic/i.test(message)) severity = 'critical';
    else if (/error|fail|denied|attack|exploit/i.test(message)) severity = 'error';
    else if (/warn|warning|suspicious|unusual/i.test(message)) severity = 'warning';
  }

  // Match against vulnerability patterns
  let matchedPattern: typeof VULNERABILITY_PATTERNS[0] | undefined;
  let cve: string | undefined;

  for (const pattern of VULNERABILITY_PATTERNS) {
    if (pattern.pattern.test(message) || pattern.pattern.test(rawLog)) {
      matchedPattern = pattern;
      // Upgrade severity if pattern is more severe
      if (severityOrder(pattern.severity) > severityOrder(severity)) {
        severity = pattern.severity as any;
      }
      // Extract CVE if present
      const cveMatch = message.match(/CVE-\d{4}-\d+/i) || rawLog.match(/CVE-\d{4}-\d+/i);
      if (cveMatch) cve = cveMatch[0];
      break;
    }
  }

  return { timestamp, source, sourceIp, destinationIp, severity, message, rawLog, matchedPattern, cve };
}

/**
 * Process a parsed log and create appropriate records
 */
export function processLog(parsed: ParsedLog): { logEntry: LogEntry; risk?: Risk } {
  // Create log entry
  const logEntry = createLogEntry({
    timestamp: parsed.timestamp,
    source: parsed.source,
    sourceIp: parsed.sourceIp,
    destinationIp: parsed.destinationIp,
    severity: parsed.severity,
    message: parsed.message,
    rawLog: parsed.rawLog,
    parsed: true,
    assetId: undefined,
    riskId: undefined,
  });

  // If a vulnerability pattern was matched, try to create a risk
  if (parsed.matchedPattern && parsed.severity !== 'info') {
    let risk: Risk | undefined;

    // Try to associate with an existing asset
    let assetId: string | undefined;
    if (parsed.sourceIp) {
      const asset = getAssetByIp(parsed.sourceIp);
      if (asset) assetId = asset.id;
    }
    if (parsed.destinationIp && !assetId) {
      const asset = getAssetByIp(parsed.destinationIp);
      if (asset) assetId = asset.id;
    }

    // Only create risk if we have an associated asset
    if (assetId && parsed.matchedPattern.title) {
      const [minCvss, maxCvss] = SEVERITY_CVSS_MAP[parsed.severity] || [0, 3.9];
      const cvssScore = Math.round((minCvss + Math.random() * (maxCvss - minCvss)) * 10) / 10;

      risk = createRisk({
        assetId,
        title: parsed.matchedPattern.titleEn || parsed.message.substring(0, 100),
        titleAr: parsed.matchedPattern.title || parsed.message.substring(0, 100),
        severity: parsed.severity as Risk['severity'],
        cvssScore,
        description: parsed.message,
        descriptionAr: parsed.message,
        exploitability: parsed.severity === 'critical' ? 85 + Math.random() * 15 : 
                        parsed.severity === 'high' ? 65 + Math.random() * 20 : 
                        40 + Math.random() * 25,
        businessImpact: parsed.severity === 'critical' ? 80 + Math.random() * 20 :
                        parsed.severity === 'high' ? 60 + Math.random() * 25 :
                        30 + Math.random() * 30,
        priority: 0, // Will be calculated by database
        cve: parsed.cve,
        status: 'open',
      });
    }
  }

  return { logEntry, risk };
}

/**
 * Parse multiple log lines (batch processing)
 */
export function processLogBatch(logs: string[], source: string = 'batch'): { entries: LogEntry[]; risks: Risk[] } {
  const entries: LogEntry[] = [];
  const risks: Risk[] = [];

  for (const rawLog of logs) {
    if (!rawLog.trim()) continue;
    const parsed = parseLogLine(rawLog, source);
    const result = processLog(parsed);
    entries.push(result.logEntry);
    if (result.risk) risks.push(result.risk);
  }

  return { entries, risks };
}

// Helper functions
function mapSeverity(level: string | number): 'info' | 'warning' | 'error' | 'critical' {
  const levelStr = String(level).toLowerCase();
  if (['critical', 'emergency', 'fatal', 'panic', 'alert'].includes(levelStr)) return 'critical';
  if (['error', 'err', 'fail', 'failed'].includes(levelStr)) return 'error';
  if (['warning', 'warn'].includes(levelStr)) return 'warning';
  return 'info';
}

function severityOrder(severity: string): number {
  switch (severity) {
    case 'critical': return 4;
    case 'error': return 3;
    case 'warning': return 2;
    case 'info': return 1;
    default: return 0;
  }
}

function parseSyslogTimestamp(ts: string): string {
  const currentYear = new Date().getFullYear();
  const parsed = new Date(`${ts} ${currentYear}`);
  return parsed.toISOString();
}
