import { Router, Request, Response } from 'express';
import {
  getAllAssets, getAssetById, createAsset, updateAsset,
  getAllRisks, getRisksByAsset, getRisksBySeverity, updateRiskStatus,
  getAllActions, getActionsByRisk, updateActionStatus,
  getRecentLogs, getLogsBySeverity, getLogsByAsset, getLogCount,
  getTestResultsByAction, getDashboardStats,
  getSystemConfig, updateAutonomyLevel, updateAuthorizedScope,
} from '../database';
import { processLogBatch, parseLogLine, processLog } from '../ingestion/logParser';
import { processAllRisks, generateActionForRisk, runSafetyTests } from '../ai/predictor';
import { broadcast } from '../websocket';
import type { ApiResponse } from '../types';

const router = Router();

// ============ DASHBOARD ============

router.get('/dashboard/stats', (_req: Request, res: Response) => {
  const stats = getDashboardStats();
  const response: ApiResponse<typeof stats> = { success: true, data: stats };
  res.json(response);
});

// ============ ASSETS ============

router.get('/assets', (_req: Request, res: Response) => {
  const assets = getAllAssets();
  res.json({ success: true, data: assets, meta: { total: assets.length } });
});

router.get('/assets/:id', (req: Request, res: Response) => {
  const asset = getAssetById(req.params.id);
  if (!asset) {
    return res.status(404).json({ success: false, error: 'Asset not found' });
  }
  res.json({ success: true, data: asset });
});

router.post('/assets', (req: Request, res: Response) => {
  try {
    const asset = createAsset(req.body);
    broadcast({
      type: 'asset_update',
      payload: { action: 'created', asset },
      timestamp: new Date().toISOString(),
    });
    res.status(201).json({ success: true, data: asset });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

router.put('/assets/:id', (req: Request, res: Response) => {
  const asset = updateAsset(req.params.id, req.body);
  if (!asset) {
    return res.status(404).json({ success: false, error: 'Asset not found' });
  }
  broadcast({
    type: 'asset_update',
    payload: { action: 'updated', asset },
    timestamp: new Date().toISOString(),
  });
  res.json({ success: true, data: asset });
});

// ============ RISKS ============

router.get('/risks', (req: Request, res: Response) => {
  const { severity, assetId } = req.query;
  let risks;
  
  if (severity) {
    risks = getRisksBySeverity(severity as string);
  } else if (assetId) {
    risks = getRisksByAsset(assetId as string);
  } else {
    risks = getAllRisks();
  }
  
  res.json({ success: true, data: risks, meta: { total: risks.length } });
});

router.put('/risks/:id/status', (req: Request, res: Response) => {
  const { status } = req.body;
  if (!['open', 'mitigating', 'resolved', 'accepted'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status' });
  }
  updateRiskStatus(req.params.id, status);
  res.json({ success: true, data: { id: req.params.id, status } });
});

// ============ AI ACTIONS ============

router.get('/actions', (_req: Request, res: Response) => {
  const actions = getAllActions();
  res.json({ success: true, data: actions, meta: { total: actions.length } });
});

router.get('/actions/risk/:riskId', (req: Request, res: Response) => {
  const actions = getActionsByRisk(req.params.riskId);
  res.json({ success: true, data: actions });
});

router.put('/actions/:id/status', (req: Request, res: Response) => {
  const { status } = req.body;
  if (!['proposed', 'testing', 'approved', 'executed', 'verified', 'failed'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status' });
  }
  updateActionStatus(req.params.id, status);
  
  broadcast({
    type: 'action_update',
    payload: { id: req.params.id, status },
    timestamp: new Date().toISOString(),
  });
  
  res.json({ success: true, data: { id: req.params.id, status } });
});

// ============ AI PREDICTION ENGINE ============

router.post('/ai/process-risks', (_req: Request, res: Response) => {
  try {
    const actions = processAllRisks();
    broadcast({
      type: 'action_update',
      payload: {
        message: `AI generated ${actions.length} new actions`,
        count: actions.length,
      },
      timestamp: new Date().toISOString(),
    });
    res.json({ success: true, data: actions, meta: { total: actions.length } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/ai/generate-action/:riskId', (req: Request, res: Response) => {
  try {
    const risks = getAllRisks();
    const risk = risks.find(r => r.id === req.params.riskId);
    if (!risk) {
      return res.status(404).json({ success: false, error: 'Risk not found' });
    }
    const action = generateActionForRisk(risk);
    if (!action) {
      return res.status(500).json({ success: false, error: 'Failed to generate action' });
    }
    res.status(201).json({ success: true, data: action });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============ SAFE TESTING ============

router.post('/testing/run/:actionId', (req: Request, res: Response) => {
  try {
    const results = runSafetyTests(req.params.actionId);
    res.json({ 
      success: true, 
      data: results,
      meta: { 
        total: results.length,
        passed: results.filter(r => r.passed).length,
        failed: results.filter(r => !r.passed).length,
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/testing/results/:actionId', (req: Request, res: Response) => {
  const results = getTestResultsByAction(req.params.actionId);
  res.json({ success: true, data: results });
});

// ============ LOGS ============

router.get('/logs', (req: Request, res: Response) => {
  const { severity, assetId, limit } = req.query;
  const logLimit = parseInt(limit as string) || 100;
  let logs;
  
  if (severity) {
    logs = getLogsBySeverity(severity as string, logLimit);
  } else if (assetId) {
    logs = getLogsByAsset(assetId as string, logLimit);
  } else {
    logs = getRecentLogs(logLimit);
  }
  
  const total = getLogCount();
  res.json({ success: true, data: logs, meta: { total, limit: logLimit } });
});

// POST /api/logs - Ingest logs (main entry point for real data)
router.post('/logs', (req: Request, res: Response) => {
  try {
    const { logs, source } = req.body;
    
    if (Array.isArray(logs)) {
      // Batch log ingestion
      const results = processLogBatch(logs, source || 'api');
      
      broadcast({
        type: 'log',
        payload: {
          processed: results.entries.length,
          risksFound: results.risks.length,
        },
        timestamp: new Date().toISOString(),
      });

      // If risks were found, trigger AI processing
      if (results.risks.length > 0) {
        const actions = processAllRisks();
        broadcast({
          type: 'action_update',
          payload: {
            message: `AI generated ${actions.length} actions for new risks`,
            count: actions.length,
          },
          timestamp: new Date().toISOString(),
        });
      }

      res.status(201).json({
        success: true,
        data: {
          entriesProcessed: results.entries.length,
          risksCreated: results.risks.length,
          entries: results.entries,
          risks: results.risks,
        },
      });
    } else if (typeof req.body === 'object' && req.body.rawLog) {
      // Single log entry
      const parsed = parseLogLine(req.body.rawLog, source || 'api');
      const result = processLog(parsed);
      
      res.status(201).json({
        success: true,
        data: {
          entry: result.logEntry,
          risk: result.risk || null,
        },
      });
    } else {
      res.status(400).json({ success: false, error: 'Invalid log format. Send { logs: string[], source?: string } or { rawLog: string, source?: string }' });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/logs/syslog - Accept syslog format
router.post('/logs/syslog', (req: Request, res: Response) => {
  try {
    const rawLog = req.body.toString();
    const parsed = parseLogLine(rawLog, 'syslog');
    const result = processLog(parsed);
    
    res.status(201).json({
      success: true,
      data: { entry: result.logEntry, risk: result.risk || null },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============ SYSTEM CONFIG ============

router.get('/config', (_req: Request, res: Response) => {
  const config = getSystemConfig();
  res.json({ success: true, data: config });
});

router.put('/config/autonomy', (req: Request, res: Response) => {
  const { level } = req.body;
  if (level < 1 || level > 5) {
    return res.status(400).json({ success: false, error: 'Level must be between 1 and 5' });
  }
  updateAutonomyLevel(level);
  res.json({ success: true, data: { autonomyLevel: level } });
});

router.put('/config/scope', (req: Request, res: Response) => {
  const { scope } = req.body;
  // Validate CIDR notation
  const cidrRegex = /^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/;
  if (!cidrRegex.test(scope)) {
    return res.status(400).json({ success: false, error: 'Invalid CIDR notation' });
  }
  updateAuthorizedScope(scope);
  res.json({ success: true, data: { authorizedScope: scope } });
});

// ============ HEALTH CHECK ============

router.get('/health', (_req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      status: 'healthy',
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      version: '1.0.0',
    },
  });
});

export default router;
