// Shared types between frontend and backend

export interface Asset {
  id: string;
  name: string;
  type: 'server' | 'database' | 'endpoint' | 'network' | 'application' | 'cloud';
  ip: string;
  os?: string;
  criticality: 'critical' | 'high' | 'medium' | 'low';
  status: 'active' | 'inactive' | 'vulnerable' | 'unknown';
  lastScan: string;
  openPorts?: number[];
  services?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Risk {
  id: string;
  assetId: string;
  title: string;
  titleAr: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  cvssScore: number;
  description: string;
  descriptionAr: string;
  exploitability: number;
  businessImpact: number;
  priority: number;
  cve?: string;
  discoveredAt: string;
  resolvedAt?: string;
  status: 'open' | 'mitigating' | 'resolved' | 'accepted';
}

export interface AIAction {
  id: string;
  riskId: string;
  actionType: 'patch' | 'isolate' | 'block' | 'monitor' | 'remediate' | 'scan';
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  reasoning: string;
  reasoningAr: string;
  confidence: number;
  safetyScore: number;
  estimatedTime: string;
  cost: number;
  successProbability: number;
  evidence: string[];
  evidenceAr: string[];
  status: 'proposed' | 'testing' | 'approved' | 'executed' | 'verified' | 'failed';
  autonomyLevel: number;
  createdAt: string;
  executedAt?: string;
}

export interface TestResult {
  id: string;
  actionId: string;
  testName: string;
  testNameAr: string;
  passed: boolean;
  duration: string;
  details: string;
  detailsAr: string;
  timestamp: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  source: string;
  sourceIp?: string;
  destinationIp?: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  rawLog: string;
  parsed: boolean;
  assetId?: string;
  riskId?: string;
  createdAt: string;
}

export interface ScanResult {
  id: string;
  assetId: string;
  scanType: 'port' | 'vulnerability' | 'compliance' | 'configuration';
  findings: ScanFinding[];
  startedAt: string;
  completedAt: string;
  status: 'running' | 'completed' | 'failed';
}

export interface ScanFinding {
  id: string;
  scanId: string;
  type: 'open_port' | 'vulnerability' | 'misconfiguration' | 'compliance_violation';
  title: string;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  details: string;
  cve?: string;
  cvssScore?: number;
}

export interface WebSocketMessage {
  type: 'log' | 'asset_update' | 'risk_alert' | 'action_update' | 'scan_progress' | 'system_status';
  payload: any;
  timestamp: string;
}

export interface AutonomyMetrics {
  level: number;
  accuracy: number;
  costReduction: number;
  responseTime: number;
  falsePositives: number;
  decisionsMade: number;
  humanOverrides: number;
  timestamp: string;
}

export interface SystemConfig {
  id: string;
  authorizedScope: string; // CIDR notation e.g., "10.0.0.0/16"
  autonomyLevel: number;
  logSources: LogSource[];
  scanSchedule: string;
  alertThresholds: AlertThresholds;
}

export interface LogSource {
  id: string;
  name: string;
  type: 'syslog' | 'api' | 'file' | 'websocket';
  endpoint?: string;
  port?: number;
  format: 'json' | 'syslog' | 'csv' | 'raw';
  enabled: boolean;
}

export interface AlertThresholds {
  criticalRiskCount: number;
  highRiskCount: number;
  responseTimeSeconds: number;
  falsePositiveRate: number;
}

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  meta?: {
    total: number;
    page: number;
    limit: number;
  };
}

export interface DashboardStats {
  totalAssets: number;
  vulnerableAssets: number;
  totalRisks: number;
  criticalRisks: number;
  highRisks: number;
  actionsProposed: number;
  actionsVerified: number;
  avgConfidence: number;
  avgSafety: number;
  testsPassed: number;
  totalTests: number;
  logsProcessed: number;
  lastScanTime: string;
}
